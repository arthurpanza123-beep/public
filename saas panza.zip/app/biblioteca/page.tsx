import { AppShell } from '@/components/app-shell'
import { LibraryView } from '@/components/library-view'

export default function BibliotecaPage() {
  return (
    <AppShell>
      <LibraryView />
    </AppShell>
  )
}
