import type { Metadata, Viewport } from 'next'
import { Inter_Tight, Geist_Mono } from 'next/font/google'
import { Toaster } from 'sonner'
import './globals.css'

const interTight = Inter_Tight({
  variable: '--font-inter-tight',
  subsets: ['latin'],
  weight: ['400', '500', '600', '700', '800', '900'],
})
const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
})

export const metadata: Metadata = {
  title: 'Panza Creator — Estúdio de Conteúdo com IA',
  description: 'Crie vídeos, thumbnails e roteiros com IA. Da ideia à publicação, tudo em um só lugar.',
  generator: 'v0.app',
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#08080a',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR" className={`${interTight.variable} ${geistMono.variable} bg-[#08080a]`}>
      <body className="font-sans antialiased">
        {children}
        <Toaster
          theme="dark"
          position="bottom-center"
          toastOptions={{
            style: {
              background: '#141417',
              border: '1px solid #26262c',
              color: '#f4f4f6',
            },
          }}
        />
      </body>
    </html>
  )
}
