import { AppShell } from '@/components/app-shell'
import { ProfileSettings } from '@/components/profile-settings'
import { Tv2, Smartphone, Camera, Bell, CreditCard, ChevronRight, Check, Zap } from 'lucide-react'

const platforms = [
  { name: 'YouTube',   icon: Tv2,        connected: true,  desc: '@gabrielpanza · 48.200 inscritos' },
  { name: 'TikTok',    icon: Smartphone, connected: true,  desc: '@panza · 12.500 seguidores' },
  { name: 'Instagram', icon: Camera,     connected: false, desc: 'Não conectado' },
]

const planFeatures = [
  'Roteiros ilimitados com IA',
  'Publicação automática no YouTube',
  'Cortes para Shorts e Reels',
  'Alertas de oportunidades via WhatsApp',
  'Thumbnails geradas por IA',
  'Descrição e tags automáticas',
]

export default function ConfiguracoesPage() {
  return (
    <AppShell>
      <div className="px-8 py-7 max-w-[820px] mx-auto flex flex-col gap-6 pb-12">
        <div>
          <h1 className="text-[26px] font-extrabold text-white tracking-tight">Configurações</h1>
          <p className="text-[13.5px] text-white/40 mt-1">Conta, plataformas conectadas e plano</p>
        </div>

        {/* Perfil + personalização */}
        <ProfileSettings />

        {/* Plataformas */}
        <section className="glass-card rounded-xl overflow-hidden">
          <div className="px-5 py-3" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
            <p className="text-[12px] font-bold uppercase tracking-[0.12em] text-white/30">Plataformas conectadas</p>
          </div>
          {platforms.map((p, i) => {
            const Icon = p.icon
            return (
              <div
                key={p.name}
                className="flex items-center gap-4 px-5 py-4"
                style={{ borderBottom: i < platforms.length - 1 ? '1px solid rgba(255,255,255,0.05)' : 'none' }}
              >
                <div
                  className="size-9 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
                >
                  <Icon className="size-4 text-white/50" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[13.5px] font-semibold text-white">{p.name}</p>
                  <p className="text-[11.5px] text-white/35">{p.desc}</p>
                </div>
                {p.connected ? (
                  <span
                    className="text-[11.5px] font-bold px-3 py-1 rounded"
                    style={{ background: 'rgba(74,222,128,0.1)', color: '#4ade80' }}
                  >
                    Conectado
                  </span>
                ) : (
                  <button
                    className="btn-accent text-[12.5px] font-bold px-3 py-1.5 rounded-lg"
                  >
                    Conectar
                  </button>
                )}
              </div>
            )
          })}
        </section>

        {/* WhatsApp */}
        <section className="glass-card rounded-xl overflow-hidden">
          <div className="px-5 py-3" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
            <p className="text-[12px] font-bold uppercase tracking-[0.12em] text-white/30">Alertas de oportunidades</p>
          </div>
          <div className="p-5 flex items-center gap-4">
            <div
              className="size-9 rounded-lg flex items-center justify-center flex-shrink-0"
              style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.10)' }}
            >
              <Bell className="size-4 text-white/70" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[13.5px] font-semibold text-white">WhatsApp</p>
              <p className="text-[11.5px] text-white/35">
                Receba um aviso quando a IA detectar um tema em alta no seu nicho
              </p>
            </div>
            <button className="btn-accent flex items-center gap-1.5 text-[12.5px] font-bold px-3 py-1.5 rounded-lg">
              Ativar
              <ChevronRight className="size-3.5" />
            </button>
          </div>
        </section>

        {/* Plano */}
        <section className="rounded-xl overflow-hidden" style={{ border: '1px solid rgba(255,255,255,0.14)' }}>
          <div
            className="px-5 py-3 flex items-center justify-between"
            style={{ background: 'rgba(255,255,255,0.05)', borderBottom: '1px solid rgba(255,255,255,0.10)' }}
          >
            <p className="text-[12px] font-bold uppercase tracking-[0.12em] text-white/30">Seu plano</p>
            <span
              className="flex items-center gap-1.5 text-[10.5px] font-bold px-2.5 py-1 rounded"
              style={{ background: '#f4f4f6', color: '#0a0a0c' }}
            >
              <Zap className="size-3" /> Creator Pro
            </span>
          </div>
          <div className="p-5" style={{ background: 'rgba(20,20,24,0.55)' }}>
            <div className="grid grid-cols-2 gap-2 mb-5">
              {planFeatures.map((f) => (
                <div key={f} className="flex items-center gap-2">
                  <Check className="size-3.5 flex-shrink-0 text-white/80" />
                  <span className="text-[12.5px] text-white/65">{f}</span>
                </div>
              ))}
            </div>
            <div className="flex items-center justify-between pt-4" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
              <div>
                <p className="text-[13px] text-white/40">Próxima cobrança</p>
                <p className="text-[13.5px] font-semibold text-white">R$ 197/mês · 15 jul 2026</p>
              </div>
              <button
                className="glass-soft flex items-center gap-2 h-9 px-4 rounded-lg text-[12.5px] font-semibold text-white/60 transition-colors hover:text-white"
              >
                <CreditCard className="size-3.5" />
                Gerenciar plano
              </button>
            </div>
          </div>
        </section>
      </div>
    </AppShell>
  )
}
