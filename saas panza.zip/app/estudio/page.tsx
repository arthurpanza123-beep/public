import { AppShell } from '@/components/app-shell'
import { AIStudio } from '@/components/ai-studio'

export default async function EstudioPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>
}) {
  const { q } = await searchParams
  return (
    <AppShell>
      <AIStudio initialQ={q} />
    </AppShell>
  )
}
