'use client'

import { useState } from 'react'
import { AppShell } from '@/components/app-shell'
import { opportunities } from '@/lib/mock-data'
import type { Opportunity } from '@/lib/mock-data'
import { TrendingUp, ArrowRight, Bell, Zap } from 'lucide-react'
import { OpportunityModal, WhatsAppModal } from '@/components/modals'
import Link from 'next/link'

export default function OportunidadesPage() {
  const [selected, setSelected] = useState<Opportunity | null>(null)
  const [whatsappOpen, setWhatsappOpen] = useState(false)

  return (
    <AppShell>
      <div className="px-8 py-7 max-w-[1240px] mx-auto flex flex-col gap-7">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-[26px] font-extrabold text-white tracking-tight">Oportunidades</h1>
            <p className="text-[13.5px] text-white/40 mt-1">
              A IA monitora o YouTube e detecta temas em alta no seu nicho — crie antes da janela fechar
            </p>
          </div>
          <button
            onClick={() => setWhatsappOpen(true)}
            className="glass-soft flex items-center gap-2 h-9 px-4 rounded-lg text-[12.5px] font-semibold flex-shrink-0 text-white/70 transition-colors hover:text-white"
          >
            <Bell className="size-3.5" />
            Ativar alertas WhatsApp
          </button>
        </div>

        {/* List */}
        <div className="flex flex-col gap-3">
          {opportunities.map((o, idx) => (
            <div
              key={o.id}
              className="glass-card glass-card-hover group flex items-center gap-5 p-5 rounded-xl transition-all duration-150 cursor-pointer"
              onClick={() => setSelected(o)}
            >
              {/* Rank */}
              <div
                className="size-9 rounded-lg flex items-center justify-center text-[14px] font-extrabold flex-shrink-0"
                style={idx === 0
                  ? { background: '#f4f4f6', color: '#0a0a0c' }
                  : { background: 'rgba(255,255,255,0.06)', color: 'rgba(255,255,255,0.35)' }
                }
              >
                {idx + 1}
              </div>

              {/* Thumbnail preview */}
              <div className="relative rounded-lg overflow-hidden flex-shrink-0" style={{ width: '112px', aspectRatio: '16/9', background: '#161618' }}>
                <img src={o.thumb} alt="" className="w-full h-full object-cover" crossOrigin="anonymous" />
                <div className="absolute inset-0" style={{ background: 'rgba(0,0,0,0.25)' }} />
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1.5">
                  <span
                    className="text-[9.5px] font-bold uppercase tracking-wide px-2 py-0.5 rounded"
                    style={o.tag === 'Em alta'
                      ? { background: 'rgba(255,255,255,0.14)', color: '#f4f4f6' }
                      : o.tag === 'Subindo'
                      ? { background: 'rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.7)' }
                      : { background: 'rgba(255,255,255,0.05)', color: 'rgba(255,255,255,0.5)' }
                    }
                  >
                    {o.tag}
                  </span>
                  <span className="text-[11.5px] text-white/35">{o.niche}</span>
                  <span className="text-white/20">·</span>
                  <span className="text-[11.5px] text-white/35">{o.views}</span>
                </div>
                <p className="text-[15px] font-semibold text-white leading-snug">{o.title}</p>
                {/* Heat bar */}
                <div className="flex items-center gap-2.5 mt-3">
                  <div className="h-1 rounded-full overflow-hidden" style={{ width: '120px', background: '#1f1f24' }}>
                    <div className="h-full rounded-full" style={{ width: `${o.heat}%`, background: '#f4f4f6' }} />
                  </div>
                  <div className="flex items-center gap-1">
                    <TrendingUp className="size-3 text-white/50" />
                    <span className="text-[12px] font-bold text-white">{o.heat}</span>
                    <span className="text-[10.5px] text-white/30">/100</span>
                  </div>
                </div>
              </div>

              {/* CTA */}
              <Link
                href={`/estudio?q=${encodeURIComponent(o.title)}`}
                className="btn-accent flex items-center gap-1.5 h-9 px-4 rounded-lg text-[12.5px] font-bold flex-shrink-0"
                onClick={(e) => e.stopPropagation()}
              >
                <Zap className="size-3.5" />
                Criar roteiro
                <ArrowRight className="size-3.5 group-hover:translate-x-0.5 transition-transform" />
              </Link>
            </div>
          ))}
        </div>
      </div>

      {selected && <OpportunityModal op={selected} onClose={() => setSelected(null)} />}
      {whatsappOpen && <WhatsAppModal onClose={() => setWhatsappOpen(false)} />}
    </AppShell>
  )
}
