import { AppShell } from '@/components/app-shell'
import { videos } from '@/lib/mock-data'
import { Download, Sparkles } from 'lucide-react'

export default function ThumbnailsPage() {
  return (
    <AppShell>
      <div className="px-8 py-8 max-w-[1240px] mx-auto flex flex-col gap-6">
        <div>
          <h1 className="text-[26px] font-extrabold text-white tracking-tight">Thumbnails</h1>
          <p className="text-[13.5px] text-white/45 mt-1">Thumbnails geradas por IA que aumentam seus cliques</p>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-5">
          {videos.map((v) => (
            <div key={v.id} className="group flex flex-col gap-2.5">
              <div className="glass-card relative aspect-video rounded-lg overflow-hidden">
                <img src={v.thumbnail || '/placeholder.svg'} alt={v.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.04]" crossOrigin="anonymous" />
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.5)' }}>
                  <button className="btn-accent flex items-center gap-2 h-9 px-4 rounded-lg text-[13px] font-bold">
                    <Download className="size-4" /> Baixar
                  </button>
                </div>
                <span className="absolute top-2 left-2 flex items-center gap-1 text-[10px] font-bold px-2 py-1 rounded" style={{ background: 'rgba(244,244,246,0.95)', color: '#0a0a0c' }}>
                  <Sparkles className="size-3" /> IA
                </span>
              </div>
              <p className="text-[13px] font-medium text-white/85 line-clamp-1 px-0.5">{v.title}</p>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  )
}
