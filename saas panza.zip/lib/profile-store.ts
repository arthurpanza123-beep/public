'use client'

import { useSyncExternalStore } from 'react'
import type {
  ContentType,
  OnboardingDraft,
  OnboardingProfile,
  OnboardingWorkflowStage,
  RecurringTask,
} from './onboarding-types'
import {
  DEFAULT_CONTENT_TYPES,
  DEFAULT_RECURRING_TASKS,
  DEFAULT_WORKFLOW_STAGES,
  routeForGoal,
} from './onboarding-options'

/** Versão do schema local. Incrementar exige migração segura (sem perda de dados). */
export const SCHEMA_VERSION = 1

const KEYS = {
  version: 'panza:schema-version',
  profile: 'panza:profile',
  draft: 'panza:onboarding-draft',
  contentTypes: 'panza:content-types',
  workflow: 'panza:workflow',
  recurringTasks: 'panza:recurring-tasks',
  /** chaves que indicam que já existem dados relevantes de um usuário antigo */
  legacyData: ['panza:videos', 'panza:projects', 'panza:clients', 'panza:tasks'],
} as const

const isBrowser = typeof window !== 'undefined'

/* ------------------------------------------------------------------ */
/* leitura / escrita básica                                            */
/* ------------------------------------------------------------------ */

function read<T>(key: string): T | null {
  if (!isBrowser) return null
  try {
    const raw = window.localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : null
  } catch {
    return null
  }
}

function write<T>(key: string, value: T): void {
  if (!isBrowser) return
  try {
    window.localStorage.setItem(key, JSON.stringify(value))
  } catch {
    /* ignora quota / modo privado */
  }
}

/**
 * Snapshot em cache para o useSyncExternalStore. loadProfile() retorna um novo
 * objeto a cada chamada (JSON.parse), o que causa loop infinito no hook. Aqui
 * mantemos a mesma referência enquanto o JSON bruto não mudar.
 */
let cachedRaw: string | null = null
let cachedProfile: OnboardingProfile | null = null

function getProfileSnapshot(): OnboardingProfile | null {
  if (!isBrowser) return null
  const raw = window.localStorage.getItem(KEYS.profile)
  if (raw === cachedRaw) return cachedProfile
  cachedRaw = raw
  try {
    cachedProfile = raw ? (JSON.parse(raw) as OnboardingProfile) : null
  } catch {
    cachedProfile = null
  }
  return cachedProfile
}

/* ------------------------------------------------------------------ */
/* store reativa (useSyncExternalStore)                                */
/* ------------------------------------------------------------------ */

const listeners = new Set<() => void>()

function emit() {
  listeners.forEach((l) => l())
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener)
  if (isBrowser) window.addEventListener('storage', listener)
  return () => {
    listeners.delete(listener)
    if (isBrowser) window.removeEventListener('storage', listener)
  }
}

/* ------------------------------------------------------------------ */
/* migração                                                            */
/* ------------------------------------------------------------------ */

export function ensureSchema(): void {
  if (!isBrowser) return
  const current = read<number>(KEYS.version)
  if (current === SCHEMA_VERSION) return
  // Migração v0 -> v1: apenas registra a versão. Nenhum dado é apagado.
  write(KEYS.version, SCHEMA_VERSION)
}

/* ------------------------------------------------------------------ */
/* perfil                                                              */
/* ------------------------------------------------------------------ */

export function loadProfile(): OnboardingProfile | null {
  return read<OnboardingProfile>(KEYS.profile)
}

export function saveProfile(profile: OnboardingProfile): void {
  write(KEYS.profile, profile)
  // invalida o cache do snapshot para refletir imediatamente
  cachedRaw = null
  emit()
}

export function updateProfile(patch: Partial<OnboardingProfile>): OnboardingProfile | null {
  const current = loadProfile()
  if (!current) return null
  const next: OnboardingProfile = { ...current, ...patch, updatedAt: new Date().toISOString() }
  saveProfile(next)
  return next
}

/* ------------------------------------------------------------------ */
/* rascunho (pausar e continuar)                                       */
/* ------------------------------------------------------------------ */

export function loadDraft(): OnboardingDraft | null {
  return read<OnboardingDraft>(KEYS.draft)
}

export function saveDraft(draft: OnboardingDraft): void {
  write(KEYS.draft, draft)
  emit()
}

export function clearDraft(): void {
  if (!isBrowser) return
  window.localStorage.removeItem(KEYS.draft)
  emit()
}

/* ------------------------------------------------------------------ */
/* coleções derivadas (tipos de conteúdo, fluxo, tarefas)              */
/* ------------------------------------------------------------------ */

export function getContentTypes(): ContentType[] {
  return read<ContentType[]>(KEYS.contentTypes) ?? DEFAULT_CONTENT_TYPES
}

export function getWorkflowStages(): OnboardingWorkflowStage[] {
  return read<OnboardingWorkflowStage[]>(KEYS.workflow) ?? DEFAULT_WORKFLOW_STAGES
}

export function getRecurringTasks(): RecurringTask[] {
  return read<RecurringTask[]>(KEYS.recurringTasks) ?? []
}

/* ------------------------------------------------------------------ */
/* gating                                                              */
/* ------------------------------------------------------------------ */

function hasLegacyData(): boolean {
  if (!isBrowser) return false
  return KEYS.legacyData.some((k) => {
    const raw = window.localStorage.getItem(k)
    if (!raw) return false
    try {
      const parsed = JSON.parse(raw)
      return Array.isArray(parsed) ? parsed.length > 0 : Boolean(parsed)
    } catch {
      return false
    }
  })
}

/**
 * Decide se o onboarding deve aparecer automaticamente.
 * - concluído -> nunca
 * - adiado ("continuar depois") -> não dispara automático
 * - existem dados antigos relevantes -> não obriga (mostra banner opcional)
 * - instalação vazia -> mostra
 */
export function shouldShowOnboarding(): boolean {
  if (!isBrowser) return false
  const profile = loadProfile()
  if (profile?.onboardingCompleted) return false
  if (profile?.onboardingDeferred) return false
  if (hasLegacyData()) return false
  return true
}

/** True quando há um usuário antigo (com dados) que ainda não personalizou. */
export function isLegacyUserPending(): boolean {
  if (!isBrowser) return false
  const profile = loadProfile()
  if (profile?.onboardingCompleted) return false
  return hasLegacyData() || Boolean(profile?.onboardingDeferred)
}

/* ------------------------------------------------------------------ */
/* conclusão idempotente                                               */
/* ------------------------------------------------------------------ */

function mergeContentTypes(selectedIds: string[], customTypes: ContentType[]): ContentType[] {
  const existing = getContentTypes()
  const byId = new Map(existing.map((t) => [t.id, t]))
  // adiciona apenas tipos personalizados ainda inexistentes
  for (const ct of customTypes) {
    if (!byId.has(ct.id)) byId.set(ct.id, ct)
  }
  // garante que os selecionados padrão também existam
  for (const id of selectedIds) {
    if (!byId.has(id)) {
      const def = DEFAULT_CONTENT_TYPES.find((d) => d.id === id)
      if (def) byId.set(id, def)
    }
  }
  return Array.from(byId.values())
}

function mergeWorkflow(stages: OnboardingWorkflowStage[]): OnboardingWorkflowStage[] {
  return stages
}

function buildRecurringTasks(taskIds: string[]): RecurringTask[] {
  const existing = getRecurringTasks()
  const byId = new Map(existing.map((t) => [t.id, t]))
  for (const id of taskIds) {
    if (!byId.has(id)) {
      const def = DEFAULT_RECURRING_TASKS.find((d) => d.id === id)
      if (def) byId.set(id, def)
    }
  }
  return Array.from(byId.values())
}

export type CompleteOnboardingInput = {
  profile: Omit<
    OnboardingProfile,
    'id' | 'createdAt' | 'updatedAt' | 'onboardingCompleted' | 'onboardingCompletedAt' | 'defaultHomeRoute'
  >
  customContentTypes: ContentType[]
}

/**
 * Persiste tudo de forma idempotente: chamar mais de uma vez não duplica dados
 * nem sobrescreve tipos/tarefas já existentes.
 */
export function completeOnboarding(input: CompleteOnboardingInput): OnboardingProfile {
  ensureSchema()
  const existing = loadProfile()

  // idempotência: se já concluído, retorna o perfil atual sem recriar nada
  if (existing?.onboardingCompleted) return existing

  const now = new Date().toISOString()
  const primaryGoal = input.profile.primaryGoal
  const defaultHomeRoute = routeForGoal(primaryGoal)

  const profile: OnboardingProfile = {
    id: existing?.id ?? (isBrowser ? crypto.randomUUID() : 'profile'),
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
    onboardingCompleted: true,
    onboardingCompletedAt: now,
    onboardingDeferred: false,
    defaultHomeRoute,
    ...input.profile,
  }

  // cria apenas o que ainda não existe
  write(KEYS.contentTypes, mergeContentTypes(profile.contentTypeIds, input.customContentTypes))
  write(KEYS.workflow, mergeWorkflow(profile.workflowStages))
  write(KEYS.recurringTasks, buildRecurringTasks(profile.recurringTaskIds))

  saveProfile(profile)
  clearDraft()
  return profile
}

/**
 * Marca o onboarding como adiado ("continuar depois") sem concluir nem criar
 * dados. Mantém o rascunho para retomada e impede o disparo automático.
 */
export function deferOnboarding(partial: Partial<OnboardingProfile>): void {
  const now = new Date().toISOString()
  const existing = loadProfile()
  const profile: OnboardingProfile = {
    id: existing?.id ?? (isBrowser ? crypto.randomUUID() : 'profile'),
    displayName: '',
    role: '',
    operationType: 'solo',
    goals: [],
    primaryGoal: '',
    contentTypeIds: [],
    weeklyVolume: '',
    publishingDays: [],
    workflowStages: [],
    recurringTaskIds: [],
    taskRecurrence: 'workdays',
    showOverdueHighlights: true,
    taskVisibility: 'today',
    defaultHomeRoute: '/',
    ...existing,
    ...partial,
    onboardingCompleted: false,
    onboardingDeferred: true,
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
  }
  saveProfile(profile)
}

/* ------------------------------------------------------------------ */
/* hooks                                                               */
/* ------------------------------------------------------------------ */

export function useProfile(): OnboardingProfile | null {
  return useSyncExternalStore(subscribe, getProfileSnapshot, () => null)
}

const FALLBACK_NAME = 'Gabriel Panza'

/** Nome de exibição com fallback seguro (nunca "Usuário" ou nome fixo aleatório). */
export function useDisplayName(): string {
  const profile = useProfile()
  const name = profile?.professionalName?.trim() || profile?.displayName?.trim()
  return name || FALLBACK_NAME
}

export function initialsFromName(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean)
  if (parts.length === 0) return 'P'
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase()
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}
