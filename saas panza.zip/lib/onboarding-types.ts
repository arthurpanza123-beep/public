export type OperationType = 'solo' | 'partners' | 'small_team' | 'studio'

export type TaskRecurrence = 'daily' | 'workdays' | 'specific' | 'none'

export type TaskVisibility = 'today' | 'upcoming'

export type OnboardingWorkflowStage = {
  id: string
  label: string
  enabled: boolean
  /** etapas adicionadas pela pessoa durante o onboarding */
  custom?: boolean
}

export type ContentType = {
  id: string
  label: string
  /** tipo criado manualmente pela pessoa */
  custom?: boolean
}

export type RecurringTask = {
  id: string
  label: string
  recurrence: TaskRecurrence
}

export type OnboardingProfile = {
  id: string
  displayName: string
  professionalName?: string
  role: string
  operationType: OperationType
  teamSize?: number
  teamRoles?: string[]
  goals: string[]
  primaryGoal: string
  contentTypeIds: string[]
  weeklyVolume: string
  publishingDays: number[]
  workflowStages: OnboardingWorkflowStage[]
  recurringTaskIds: string[]
  taskRecurrence: TaskRecurrence
  workdayStart?: string
  workdayEnd?: string
  dailyReviewTime?: string
  showOverdueHighlights: boolean
  taskVisibility: TaskVisibility
  defaultHomeRoute: string
  onboardingCompleted: boolean
  onboardingCompletedAt?: string
  /** pessoa optou por "continuar depois" */
  onboardingDeferred?: boolean
  createdAt: string
  updatedAt: string
}

/** Rascunho parcial salvo a cada etapa para permitir pausar e continuar. */
export type OnboardingDraft = {
  step: number
  data: Partial<OnboardingProfile>
  /** tipos de conteúdo personalizados criados durante o onboarding */
  customContentTypes?: ContentType[]
  updatedAt: string
}
