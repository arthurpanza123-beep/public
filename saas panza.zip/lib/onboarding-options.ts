import type {
  ContentType,
  OnboardingWorkflowStage,
  OperationType,
  RecurringTask,
} from './onboarding-types'

export const ROLE_OPTIONS: string[] = [
  'Editor de vídeo',
  'Videomaker',
  'Social media',
  'Produtor de conteúdo',
  'Diretor criativo',
  'Motion designer',
  'Gestor de produtora',
  'Outro',
]

export const OPERATION_OPTIONS: { id: OperationType; label: string; desc: string }[] = [
  { id: 'solo', label: 'Trabalho sozinho', desc: 'Cuido de tudo por conta própria' },
  { id: 'partners', label: 'Trabalho com parceiros', desc: 'Divido a produção com freelancers' },
  { id: 'small_team', label: 'Tenho uma pequena equipe', desc: 'Algumas pessoas fixas comigo' },
  { id: 'studio', label: 'Gerencio uma produtora', desc: 'Coordeno uma operação completa' },
]

/** id estável -> rota inicial mais relacionada (mapeada para rotas existentes do app). */
export const GOAL_OPTIONS: { id: string; label: string; route: string }[] = [
  { id: 'produce_today', label: 'Saber o que produzir hoje', route: '/' },
  { id: 'edit_queue', label: 'Organizar a fila de edição', route: '/biblioteca' },
  { id: 'never_miss_publish', label: 'Não esquecer publicações', route: '/calendario' },
  { id: 'approvals', label: 'Controlar aprovações', route: '/biblioteca' },
  { id: 'deliveries', label: 'Organizar entregas', route: '/calendario' },
  { id: 'clients', label: 'Controlar clientes', route: '/' },
  { id: 'projects', label: 'Acompanhar projetos', route: '/biblioteca' },
  { id: 'daily_tasks', label: 'Organizar tarefas diárias', route: '/' },
  { id: 'agenda', label: 'Melhorar minha agenda', route: '/calendario' },
]

export const MAX_GOALS = 3

export function routeForGoal(goalId: string): string {
  return GOAL_OPTIONS.find((g) => g.id === goalId)?.route ?? '/'
}

export function labelForGoal(goalId: string): string {
  return GOAL_OPTIONS.find((g) => g.id === goalId)?.label ?? goalId
}

export const DEFAULT_CONTENT_TYPES: ContentType[] = [
  { id: 'reels', label: 'Reels' },
  { id: 'stories', label: 'Stories' },
  { id: 'posts', label: 'Posts' },
  { id: 'carrosseis', label: 'Carrosséis' },
  { id: 'institucionais', label: 'Vídeos institucionais' },
  { id: 'podcasts', label: 'Podcasts' },
  { id: 'eventos', label: 'Cobertura de eventos' },
  { id: 'anuncios', label: 'Anúncios' },
  { id: 'youtube', label: 'YouTube' },
  { id: 'thumbnails', label: 'Thumbnails' },
  { id: 'motion', label: 'Motion design' },
]

export const WEEKLY_VOLUME_OPTIONS: string[] = [
  '1 a 5',
  '6 a 10',
  '11 a 20',
  '21 a 40',
  'Mais de 40',
  'Ainda estou começando',
]

/** 0 = Domingo ... 6 = Sábado (compatível com Date.getDay) */
export const WEEKDAYS: { value: number; short: string; label: string }[] = [
  { value: 1, short: 'Seg', label: 'Segunda' },
  { value: 2, short: 'Ter', label: 'Terça' },
  { value: 3, short: 'Qua', label: 'Quarta' },
  { value: 4, short: 'Qui', label: 'Quinta' },
  { value: 5, short: 'Sex', label: 'Sexta' },
  { value: 6, short: 'Sáb', label: 'Sábado' },
  { value: 0, short: 'Dom', label: 'Domingo' },
]

export const DEFAULT_WORKFLOW_STAGES: OnboardingWorkflowStage[] = [
  { id: 'ideia', label: 'Ideia', enabled: true },
  { id: 'briefing', label: 'Briefing', enabled: true },
  { id: 'gravacao', label: 'Gravação', enabled: true },
  { id: 'edicao', label: 'Edição', enabled: true },
  { id: 'aprovacao', label: 'Aprovação', enabled: true },
  { id: 'agendamento', label: 'Agendamento', enabled: true },
  { id: 'publicado', label: 'Publicado', enabled: true },
]

export const DEFAULT_RECURRING_TASKS: RecurringTask[] = [
  { id: 'revisar_briefings', label: 'Revisar briefings', recurrence: 'workdays' },
  { id: 'separar_materiais', label: 'Separar materiais', recurrence: 'workdays' },
  { id: 'acompanhar_gravacoes', label: 'Acompanhar gravações', recurrence: 'workdays' },
  { id: 'organizar_brutos', label: 'Organizar arquivos brutos', recurrence: 'workdays' },
  { id: 'backup', label: 'Fazer backup', recurrence: 'daily' },
  { id: 'revisar_prontos', label: 'Revisar conteúdos prontos', recurrence: 'workdays' },
  { id: 'enviar_aprovacao', label: 'Enviar para aprovação', recurrence: 'workdays' },
  { id: 'agendar_publicacoes', label: 'Agendar publicações', recurrence: 'workdays' },
  { id: 'publicar', label: 'Publicar conteúdos', recurrence: 'daily' },
  { id: 'conferir_entregas', label: 'Conferir entregas', recurrence: 'workdays' },
  { id: 'responder_clientes', label: 'Responder clientes', recurrence: 'daily' },
  { id: 'planejar_dia', label: 'Planejar o dia seguinte', recurrence: 'daily' },
]

export const TOTAL_STEPS = 10
