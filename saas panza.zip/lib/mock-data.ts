import {
  Home,
  Wand2,
  Video,
  CalendarDays,
  TrendingUp,
  Settings,
} from 'lucide-react'

export const navItems = [
  { label: 'Início',        icon: Home,        href: '/' },
  { label: 'Estúdio IA',   icon: Wand2,       href: '/estudio' },
  { label: 'Meus Vídeos',  icon: Video,       href: '/biblioteca' },
  { label: 'Calendário',   icon: CalendarDays, href: '/calendario' },
  { label: 'Oportunidades',icon: TrendingUp,   href: '/oportunidades' },
]

export const navBottom = [
  { label: 'Configurações', icon: Settings, href: '/configuracoes' },
]

export type VideoStatus = 'rascunho' | 'editando' | 'pronto' | 'publicado'

export type Opportunity = {
  id: string
  tag: string
  title: string
  heat: number
  niche: string
  thumb: string
  views: string
}

export type CalendarEvent = {
  id: string
  day: number
  platform: string
  title: string
  time: string
  thumb: string
}

export type Video = {
  id: string
  title: string
  thumbnail: string
  duration: string
  status: VideoStatus
  views?: string
  platform: 'YouTube' | 'TikTok' | 'Instagram'
  date: string
  aiGenerated: boolean
}

export const videos: Video[] = [
  {
    id: '1',
    title: 'Como eu fiz R$50 mil em 30 dias com conteúdo',
    thumbnail: '/thumbs/thumb-1.png',
    duration: '12:45',
    status: 'publicado',
    views: '1,2M',
    platform: 'YouTube',
    date: 'há 2 dias',
    aiGenerated: true,
  },
  {
    id: '2',
    title: 'O setup perfeito para criadores em 2026',
    thumbnail: '/thumbs/thumb-2.png',
    duration: '08:15',
    status: 'pronto',
    views: '340K',
    platform: 'YouTube',
    date: 'há 4 dias',
    aiGenerated: true,
  },
  {
    id: '3',
    title: 'Gravei por 24h em 3 cidades diferentes',
    thumbnail: '/thumbs/thumb-3.png',
    duration: '18:30',
    status: 'editando',
    platform: 'YouTube',
    date: 'em edição',
    aiGenerated: false,
  },
  {
    id: '4',
    title: 'A jogada que ninguém viu chegando',
    thumbnail: '/thumbs/thumb-4.png',
    duration: '22:10',
    status: 'publicado',
    views: '890K',
    platform: 'YouTube',
    date: 'há 1 semana',
    aiGenerated: true,
  },
  {
    id: '5',
    title: 'Receita de 10 minutos que viralizou',
    thumbnail: '/thumbs/thumb-5.png',
    duration: '06:40',
    status: 'rascunho',
    platform: 'TikTok',
    date: 'rascunho',
    aiGenerated: true,
  },
  {
    id: '6',
    title: 'Treino que mudou meu corpo em 90 dias',
    thumbnail: '/thumbs/thumb-6.png',
    duration: '14:20',
    status: 'editando',
    platform: 'Instagram',
    date: 'em edição',
    aiGenerated: false,
  },
]

export const statusConfig: Record<VideoStatus, { label: string; color: string; bg: string }> = {
  rascunho:  { label: 'Rascunho',  color: '#8a8a93', bg: 'rgba(138,138,147,0.15)' },
  editando:  { label: 'Editando',  color: '#f59e0b', bg: 'rgba(245,158,11,0.15)' },
  pronto:    { label: 'Pronto',    color: '#4ade80', bg: 'rgba(74,222,128,0.15)' },
  publicado: { label: 'Publicado', color: '#f4f4f6', bg: 'rgba(255,255,255,0.12)' },
}

export const calendarEvents = [
  { id: '1', day: 5,  platform: 'YouTube',   title: 'Como eu fiz R$50 mil', time: '12:00', thumb: '/thumbs/thumb-1.png' },
  { id: '2', day: 9,  platform: 'TikTok',    title: 'Corte viral 60s',       time: '18:00', thumb: '/thumbs/thumb-5.png' },
  { id: '3', day: 14, platform: 'YouTube',   title: 'Setup perfeito 2026',   time: '12:00', thumb: '/thumbs/thumb-2.png' },
  { id: '4', day: 18, platform: 'Instagram', title: 'Treino 90 dias',        time: '20:00', thumb: '/thumbs/thumb-6.png' },
  { id: '5', day: 22, platform: 'YouTube',   title: 'A jogada que ninguém viu', time: '12:00', thumb: '/thumbs/thumb-4.png' },
  { id: '6', day: 27, platform: 'TikTok',    title: 'Receita 10 min',        time: '18:00', thumb: '/thumbs/thumb-5.png' },
]

export const opportunities = [
  {
    id: '1',
    tag: 'Em alta',
    title: 'IA para criadores: como usar sem perder autenticidade',
    heat: 94,
    niche: 'Tecnologia',
    thumb: '/thumbs/thumb-2.png',
    views: '2.4M buscas',
  },
  {
    id: '2',
    tag: 'Subindo',
    title: 'Rotina matinal de criadores que faturam 6 dígitos',
    heat: 81,
    niche: 'Lifestyle',
    thumb: '/thumbs/thumb-3.png',
    views: '1.1M buscas',
  },
  {
    id: '3',
    tag: 'Em alta',
    title: 'Como investir R$100 por mês e chegar ao milhão',
    heat: 88,
    niche: 'Finanças',
    thumb: '/thumbs/thumb-1.png',
    views: '3.7M buscas',
  },
  {
    id: '4',
    tag: 'Novo',
    title: 'Os 5 erros que matam canais no YouTube em 2026',
    heat: 76,
    niche: 'YouTube',
    thumb: '/thumbs/thumb-4.png',
    views: '870K buscas',
  },
  {
    id: '5',
    tag: 'Subindo',
    title: 'Treino em casa sem equipamento que funciona de verdade',
    heat: 72,
    niche: 'Fitness',
    thumb: '/thumbs/thumb-6.png',
    views: '1.8M buscas',
  },
]
