'use client'

import { useState } from 'react'
import { Play, MoreVertical, Sparkles } from 'lucide-react'
import { statusConfig, type Video } from '@/lib/mock-data'
import { VideoModal } from './modals'

// Badges de plataforma — neutros, legíveis sobre a thumbnail
const platformColor: Record<string, string> = {
  YouTube:   'rgba(0,0,0,0.6)',
  TikTok:    'rgba(0,0,0,0.6)',
  Instagram: 'rgba(0,0,0,0.6)',
}

export function VideoCard({ video }: { video: Video }) {
  const [open, setOpen] = useState(false)
  const status = statusConfig[video.status]
  return (
    <>
      <div
        className="glass-card glass-card-hover group cursor-pointer rounded-xl overflow-hidden flex flex-col transition-all duration-200 hover:translate-y-[-2px]"
        onClick={() => setOpen(true)}
      >
      {/* Thumbnail */}
      <div className="relative aspect-video overflow-hidden" style={{ background: '#161618' }}>
        <img
          src={video.thumbnail}
          alt={video.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
          crossOrigin="anonymous"
        />

        {/* dark overlay */}
        <div
          className="absolute inset-0 transition-opacity duration-300"
          style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.6) 0%, rgba(0,0,0,0) 50%, rgba(0,0,0,0.25) 100%)' }}
        />

        {/* Play button — sempre visivel, fica maior no hover */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div
            className="size-10 rounded-full flex items-center justify-center transition-all duration-200 group-hover:scale-110"
            style={{ background: 'rgba(244,244,246,0.95)', boxShadow: '0 4px 20px rgba(0,0,0,0.4)' }}
          >
            <Play className="size-4 ml-0.5" style={{ color: '#0a0a0c', fill: '#0a0a0c' }} />
          </div>
        </div>

        {/* duration */}
        <span
          className="absolute bottom-2 right-2 text-[10.5px] font-bold text-white px-1.5 py-0.5 rounded"
          style={{ background: 'rgba(0,0,0,0.75)' }}
        >
          {video.duration}
        </span>

        {/* AI badge */}
        {video.aiGenerated && (
          <span
            className="absolute top-2 left-2 flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded"
            style={{ background: 'rgba(244,244,246,0.95)', color: '#0a0a0c' }}
          >
            <Sparkles className="size-2.5" />
            IA
          </span>
        )}

        {/* platform dot */}
        <span
          className="absolute top-2 right-2 text-[9.5px] font-bold px-2 py-0.5 rounded text-white"
          style={{ background: platformColor[video.platform] }}
        >
          {video.platform}
        </span>
      </div>

      {/* Info */}
      <div className="px-3 py-2.5 flex items-start gap-2">
        <div className="flex-1 min-w-0">
          <p className="text-[13px] font-semibold text-white leading-snug line-clamp-2">
            {video.title}
          </p>
          <div className="flex items-center gap-1.5 mt-1.5 text-[11px] text-white/35">
            {video.views
              ? <span>{video.views} views · {video.date}</span>
              : <span>{video.date}</span>
            }
          </div>
        </div>
        <div className="flex-shrink-0 mt-0.5 flex flex-col items-end gap-1.5">
          <span
            className="text-[10px] font-bold px-2 py-0.5 rounded"
            style={{ background: status.bg, color: status.color }}
          >
            {status.label}
          </span>
          <button
            onClick={(e) => { e.stopPropagation(); }}
            className="text-white/20 hover:text-white/60 transition-colors opacity-0 group-hover:opacity-100"
          >
            <MoreVertical className="size-3.5" />
          </button>
        </div>
      </div>
    </div>
      {open && <VideoModal video={video} onClose={() => setOpen(false)} />}
    </>
  )
}
