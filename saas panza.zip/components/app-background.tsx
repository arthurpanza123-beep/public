'use client'

/**
 * Fundo dinâmico sutil para todo o app — aurora neutra (branco/cinza) que
 * flutua lentamente atrás do conteúdo, no espírito Apple/Gemini. Fica fixo,
 * bem discreto, sem distrair da leitura dos cards. Respeita reduced-motion
 * via CSS (.aurora-* pausam a animação).
 */
export function AppBackground() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      <div className="absolute inset-0 bg-[#08080a]" />
      <div
        className="aurora-orb aurora-a"
        style={{
          top: '-18%',
          left: '6%',
          width: '42vw',
          height: '42vw',
          opacity: 0.5,
          background:
            'radial-gradient(circle at 35% 35%, rgba(255,255,255,0.10), rgba(255,255,255,0) 70%)',
        }}
      />
      <div
        className="aurora-orb aurora-b"
        style={{
          top: '25%',
          right: '-10%',
          width: '40vw',
          height: '40vw',
          opacity: 0.45,
          background:
            'radial-gradient(circle at 50% 50%, rgba(150,165,200,0.08), rgba(150,165,200,0) 70%)',
        }}
      />
      <div
        className="aurora-orb aurora-c"
        style={{
          bottom: '-22%',
          left: '34%',
          width: '50vw',
          height: '50vw',
          opacity: 0.4,
          background:
            'radial-gradient(circle at 50% 50%, rgba(110,118,140,0.10), rgba(110,118,140,0) 72%)',
        }}
      />
      {/* leve vinheta para manter o conteúdo legível */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(125% 125% at 50% 30%, rgba(8,8,10,0) 50%, rgba(8,8,10,0.55) 100%)',
        }}
      />
    </div>
  )
}
