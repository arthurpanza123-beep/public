'use client'

import { useState } from 'react'
import { calendarEvents } from '@/lib/mock-data'
import type { CalendarEvent } from '@/lib/mock-data'
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react'
import { CalendarEventModal, ScheduleModal } from './modals'

const weekDays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb']
// Neutros — diferenciados por tom de cinza, sem cor de marca
const platformColor: Record<string, string> = {
  YouTube: '#f4f4f6',
  TikTok: '#9a9aa3',
  Instagram: '#6e6e78',
}

// Junho 2026 começa numa segunda (offset 1)
const OFFSET = 1
const DAYS_IN_MONTH = 30

export function CalendarView() {
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null)
  const [scheduleOpen, setScheduleOpen] = useState(false)

  const cells: (number | null)[] = [
    ...Array(OFFSET).fill(null),
    ...Array.from({ length: DAYS_IN_MONTH }, (_, i) => i + 1),
  ]

  const eventsByDay = calendarEvents.reduce<Record<number, typeof calendarEvents>>((acc, e) => {
    ;(acc[e.day] ||= []).push(e)
    return acc
  }, {})

  return (
    <>
    <div className="px-8 py-8 max-w-[1240px] mx-auto flex flex-col gap-6">
      {/* Header */}
      <div className="flex items-end justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-[26px] font-extrabold text-white tracking-tight">Calendário</h1>
          <p className="text-[13.5px] text-white/45 mt-1">Suas publicações agendadas — Junho 2026</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <button className="size-9 rounded-lg flex items-center justify-center text-white/45 hover:text-white transition-colors" style={{ background: '#111113', border: '1px solid #1f1f24' }}>
              <ChevronLeft className="size-4" />
            </button>
            <button className="size-9 rounded-lg flex items-center justify-center text-white/45 hover:text-white transition-colors" style={{ background: '#111113', border: '1px solid #1f1f24' }}>
              <ChevronRight className="size-4" />
            </button>
          </div>
          <button
            onClick={() => setScheduleOpen(true)}
            className="btn-accent flex items-center gap-2 h-9 px-4 rounded-lg text-[13px] font-bold"
          >
            <Plus className="size-4" strokeWidth={2.5} />
            Agendar
          </button>
        </div>
      </div>

      {/* Calendar grid */}
      <div className="rounded-xl overflow-hidden" style={{ background: '#0d0d0f', border: '1px solid #1f1f24' }}>
        {/* Weekday header */}
        <div className="grid grid-cols-7" style={{ borderBottom: '1px solid #1f1f24' }}>
          {weekDays.map((d) => (
            <div key={d} className="py-2.5 text-center text-[11px] font-bold uppercase tracking-[0.12em] text-white/35">
              {d}
            </div>
          ))}
        </div>

        {/* Days */}
        <div className="grid grid-cols-7">
          {cells.map((day, i) => {
            const events = day ? eventsByDay[day] : undefined
            return (
              <div
                key={i}
                className="min-h-[120px] p-2 flex flex-col gap-1.5"
                style={{
                  borderRight: (i + 1) % 7 !== 0 ? '1px solid #18181b' : 'none',
                  borderBottom: '1px solid #18181b',
                  background: day ? 'transparent' : '#0a0a0c',
                }}
              >
                {day && (
                  <span className="text-[12px] font-semibold text-white/55 px-1">{day}</span>
                )}
                {events?.map((e) => (
                  <div
                    key={e.id}
                    className="group rounded-lg overflow-hidden cursor-pointer transition-transform hover:scale-[1.02]"
                    style={{ background: '#16161a', border: '1px solid #1f1f24' }}
                    onClick={() => setSelectedEvent(e)}
                  >
                    <div className="relative aspect-video">
                      <img src={e.thumb || '/placeholder.svg'} alt={e.title} className="w-full h-full object-cover" crossOrigin="anonymous" />
                      <span
                        className="absolute top-1 left-1 text-[8px] font-bold px-1.5 py-0.5 rounded"
                        style={{ background: platformColor[e.platform], color: e.platform === 'TikTok' ? '#000' : '#fff' }}
                      >
                        {e.platform}
                      </span>
                    </div>
                    <div className="px-1.5 py-1">
                      <p className="text-[10.5px] font-semibold text-white truncate leading-tight">{e.title}</p>
                      <p className="text-[9.5px] text-white/40 mt-0.5">{e.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            )
          })}
        </div>
      </div>
    </div>

    {selectedEvent && <CalendarEventModal event={selectedEvent} onClose={() => setSelectedEvent(null)} />}
    {scheduleOpen && <ScheduleModal onClose={() => setScheduleOpen(false)} />}
    </>
  )
}
