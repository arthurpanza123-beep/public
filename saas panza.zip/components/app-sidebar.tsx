'use client'

import { usePathname } from 'next/navigation'
import Link from 'next/link'
import { navItems, navBottom } from '@/lib/mock-data'
import { cn } from '@/lib/utils'
import { Upload } from 'lucide-react'
import { useProfile, useDisplayName, initialsFromName } from '@/lib/profile-store'

export function AppSidebar() {
  const pathname = usePathname()
  const profile = useProfile()
  const displayName = useDisplayName()
  const initials = initialsFromName(displayName)
  const roleLabel = profile?.role?.trim() || 'Creator Pro'

  return (
    <aside
      className="fixed left-0 top-0 w-[216px] h-screen flex flex-col z-40 select-none"
      style={{
        background: 'rgba(10,10,12,0.6)',
        backdropFilter: 'blur(24px) saturate(150%)',
        WebkitBackdropFilter: 'blur(24px) saturate(150%)',
        borderRight: '1px solid rgba(255,255,255,0.07)',
      }}
    >
      {/* Brand */}
      <div className="flex items-center gap-2.5 px-5 h-[60px] flex-shrink-0">
        <img src="/panza-p.png" alt="Panza Creator" className="h-7 w-7 object-contain" />
        <div className="flex flex-col leading-none">
          <span className="text-[13px] font-extrabold tracking-[0.06em] text-white">PANZA</span>
          <span className="text-[9px] font-semibold tracking-[0.25em] text-white/30 mt-0.5">CREATOR</span>
        </div>
      </div>

      {/* Upload CTA — acao principal: mandar vídeo bruto */}
      <div className="px-3 pb-4">
        <Link
          href="/biblioteca"
          className="btn-accent flex items-center justify-center gap-2 h-9 w-full text-[12.5px] font-bold rounded-md"
        >
          <Upload className="size-3.5" strokeWidth={2.5} />
          Enviar vídeo
        </Link>
      </div>

      {/* Main nav */}
      <nav className="flex-1 overflow-y-auto px-3 flex flex-col gap-0.5">
        {navItems.map((item) => {
          const active = pathname === item.href
          const Icon = item.icon
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 px-3 h-9 rounded-md text-[13px] font-medium transition-all duration-150',
                active
                  ? 'text-white'
                  : 'text-white/40 hover:text-white hover:bg-white/[0.04]',
              )}
              style={active ? { background: 'rgba(255,255,255,0.08)', boxShadow: 'inset 2px 0 0 rgba(255,255,255,0.85)' } : undefined}
            >
              <Icon
                className="size-[16px] flex-shrink-0"
                strokeWidth={active ? 2.3 : 1.8}
                style={{ color: active ? '#f4f4f6' : undefined }}
              />
              {item.label}
            </Link>
          )
        })}
      </nav>

      {/* Bottom: settings + profile */}
      <div className="px-3 pb-3 flex flex-col gap-0.5">
        {navBottom.map((item) => {
          const active = pathname === item.href
          const Icon = item.icon
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 px-3 h-9 rounded-md text-[13px] font-medium transition-all duration-150',
                active ? 'text-white bg-white/[0.06]' : 'text-white/35 hover:text-white hover:bg-white/[0.04]',
              )}
            >
              <Icon className="size-[16px] flex-shrink-0" strokeWidth={1.8} />
              {item.label}
            </Link>
          )
        })}
      </div>

      {/* Profile */}
      <div
        className="flex items-center gap-2.5 px-4 h-[56px] flex-shrink-0"
        style={{ borderTop: '1px solid rgba(255,255,255,0.07)' }}
      >
        <div className="size-8 rounded-full flex items-center justify-center text-[11.5px] font-bold flex-shrink-0 bg-[#f4f4f6] text-[#0a0a0c]">
          {initials}
        </div>
        <div className="flex flex-col leading-tight min-w-0">
          <span className="text-[12.5px] font-semibold text-white truncate">{displayName}</span>
          <span className="text-[10.5px] text-white/30 truncate">{roleLabel}</span>
        </div>
      </div>
    </aside>
  )
}
