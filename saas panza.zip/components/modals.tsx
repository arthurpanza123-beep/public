'use client'

import { useEffect, useRef } from 'react'
import {
  X, Play, Download, MoreVertical, Sparkles,
  ExternalLink, Tag, Clock, BarChart2,
  Zap, ArrowRight, TrendingUp, Bell, Check,
  CalendarDays, CirclePlay,
} from 'lucide-react'
import type { Video } from '@/lib/mock-data'
import { statusConfig } from '@/lib/mock-data'
import type { Opportunity } from '@/lib/mock-data'
import type { CalendarEvent } from '@/lib/mock-data'

/* ─── shared backdrop ─────────────────────────────────────── */
function Backdrop({ onClose, children }: { onClose: () => void; children: React.ReactNode }) {
  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    document.addEventListener('keydown', handler)
    return () => document.removeEventListener('keydown', handler)
  }, [onClose])

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(6px)' }}
      onClick={onClose}
    >
      <div onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>
  )
}

function CloseBtn({ onClose }: { onClose: () => void }) {
  return (
    <button
      onClick={onClose}
      className="absolute top-4 right-4 size-8 rounded-full flex items-center justify-center text-white/50 hover:text-white transition-colors z-10"
      style={{ background: 'rgba(255,255,255,0.07)' }}
    >
      <X className="size-4" />
    </button>
  )
}

/* ─── VIDEO MODAL ─────────────────────────────────────────── */
export function VideoModal({ video, onClose }: { video: Video; onClose: () => void }) {
  const status = statusConfig[video.status]
  return (
    <Backdrop onClose={onClose}>
      <div
        className="relative w-[780px] max-w-full rounded-2xl overflow-hidden flex flex-col"
        style={{ background: '#111113', border: '1px solid #1f1f24', maxHeight: '90vh' }}
      >
        <CloseBtn onClose={onClose} />

        {/* Player */}
        <div className="relative w-full" style={{ aspectRatio: '16/9', background: '#000' }}>
          <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover" crossOrigin="anonymous" />
          {/* center play */}
          <div className="absolute inset-0 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.45)' }}>
            <button
              className="size-16 rounded-full flex items-center justify-center transition-transform hover:scale-105"
              style={{ background: 'rgba(244,244,246,0.95)', boxShadow: '0 8px 32px rgba(0,0,0,0.5)' }}
            >
              <Play className="size-7 ml-1" style={{ color: '#0a0a0c', fill: '#0a0a0c' }} />
            </button>
          </div>
          {/* duration */}
          <span
            className="absolute bottom-3 right-3 text-[11px] font-bold text-white px-2 py-1 rounded"
            style={{ background: 'rgba(0,0,0,0.75)' }}
          >
            {video.duration}
          </span>
          {/* platform */}
          <span
            className="absolute top-3 left-3 text-[10px] font-bold px-2.5 py-1 rounded text-white"
            style={{ background: 'rgba(0,0,0,0.6)' }}
          >
            {video.platform}
          </span>
        </div>

        {/* Info + actions */}
        <div className="overflow-y-auto">
          <div className="p-6 flex flex-col gap-4">
            {/* title + status */}
            <div className="flex items-start gap-3">
              <h2 className="text-[18px] font-extrabold text-white tracking-tight flex-1 leading-snug">{video.title}</h2>
              <span className="text-[11px] font-bold px-2.5 py-1 rounded flex-shrink-0 mt-0.5" style={{ background: status.bg, color: status.color }}>
                {status.label}
              </span>
            </div>

            {/* meta row */}
            <div className="flex items-center gap-5 flex-wrap">
              {video.views && (
                <div className="flex items-center gap-1.5">
                  <BarChart2 className="size-3.5 text-white/30" />
                  <span className="text-[13px] text-white/55">{video.views} visualizações</span>
                </div>
              )}
              <div className="flex items-center gap-1.5">
                <Clock className="size-3.5 text-white/30" />
                <span className="text-[13px] text-white/55">{video.duration} · {video.date}</span>
              </div>
              {video.aiGenerated && (
                <span className="flex items-center gap-1.5 text-[12px] font-bold px-2.5 py-1 rounded" style={{ background: 'rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.75)' }}>
                  <Sparkles className="size-3" /> Criado com IA
                </span>
              )}
            </div>

            {/* description mock */}
            <div className="rounded-xl p-4" style={{ background: '#18181b', border: '1px solid #1a1a1d' }}>
              <p className="text-[12.5px] text-white/50 leading-relaxed">
                Nesse vídeo eu mostro como transformei minha estratégia de conteúdo e o resultado real em 30 dias. Tudo que aprendi está aqui — desde o roteiro até a thumbnail que fez o clique disparar.
              </p>
              <div className="flex flex-wrap gap-1.5 mt-3">
                {['criador de conteudo', 'youtube 2026', 'crescimento', video.platform.toLowerCase()].map((t) => (
                  <span key={t} className="text-[10.5px] px-2 py-0.5 rounded" style={{ background: 'rgba(255,255,255,0.05)', color: 'rgba(255,255,255,0.6)', border: '1px solid rgba(255,255,255,0.10)' }}>
                    <span className="text-white/40">#</span>{t}
                  </span>
                ))}
              </div>
            </div>

            {/* actions */}
            <div className="flex items-center gap-2 flex-wrap pt-1" style={{ borderTop: '1px solid #1a1a1d' }}>
              {video.status === 'publicado' ? (
                <a
                  href={`https://youtube.com`}
                  target="_blank"
                  rel="noreferrer"
                  className="btn-accent flex items-center gap-1.5 h-10 px-5 rounded-xl text-[13px] font-bold"
                >
                  <ExternalLink className="size-4" />
                  Ver no YouTube
                </a>
              ) : (
                <button
                  className="btn-accent flex items-center gap-1.5 h-10 px-5 rounded-xl text-[13px] font-bold"
                >
                  <CirclePlay className="size-4" />
                  {video.status === 'pronto' ? 'Publicar agora' : 'Continuar editando'}
                </button>
              )}
              <button
                className="flex items-center gap-1.5 h-10 px-4 rounded-xl text-[13px] font-medium text-white/60 transition-colors hover:text-white"
                style={{ background: '#18181b', border: '1px solid #1f1f24' }}
              >
                <Download className="size-4" />
                Baixar
              </button>
              <button
                className="flex items-center gap-1.5 h-10 px-4 rounded-xl text-[13px] font-medium text-white/60 transition-colors hover:text-white"
                style={{ background: '#18181b', border: '1px solid #1f1f24' }}
              >
                <MoreVertical className="size-4" />
                Mais
              </button>
            </div>
          </div>
        </div>
      </div>
    </Backdrop>
  )
}

/* ─── OPPORTUNITY MODAL ───────────────────────────────────── */
export function OpportunityModal({ op, onClose }: { op: Opportunity; onClose: () => void }) {
  return (
    <Backdrop onClose={onClose}>
      <div
        className="relative w-[580px] max-w-full rounded-2xl overflow-hidden"
        style={{ background: '#111113', border: '1px solid #1f1f24' }}
      >
        <CloseBtn onClose={onClose} />

        {/* Thumbnail hero */}
        <div className="relative w-full" style={{ aspectRatio: '16/9' }}>
          <img src={op.thumb} alt="" className="w-full h-full object-cover" crossOrigin="anonymous" />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.2) 60%)' }} />
          <div className="absolute bottom-4 left-5 right-5">
            <span
              className="text-[9.5px] font-bold uppercase tracking-wide px-2.5 py-1 rounded inline-block mb-2"
              style={op.tag === 'Em alta'
                ? { background: 'rgba(244,244,246,0.95)', color: '#0a0a0c' }
                : op.tag === 'Subindo'
                ? { background: 'rgba(255,255,255,0.18)', color: '#fff' }
                : { background: 'rgba(255,255,255,0.10)', color: '#fff' }
              }
            >
              {op.tag}
            </span>
            <h2 className="text-[18px] font-extrabold text-white tracking-tight leading-snug">{op.title}</h2>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 flex flex-col gap-4">
          {/* Stats */}
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'Buscas/mês',   value: op.views },
              { label: 'Nicho',        value: op.niche },
              { label: 'Score de calor', value: `${op.heat}/100` },
            ].map((s) => (
              <div key={s.label} className="rounded-xl p-3" style={{ background: '#18181b', border: '1px solid #1a1a1d' }}>
                <p className="text-[10.5px] text-white/35 mb-1">{s.label}</p>
                <p className="text-[14px] font-bold text-white">{s.value}</p>
              </div>
            ))}
          </div>

          {/* Heat bar */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11.5px] text-white/45 flex items-center gap-1.5">
                <TrendingUp className="size-3.5" /> Janela de oportunidade
              </span>
              <span className="text-[12px] font-bold text-white">{op.heat}%</span>
            </div>
            <div className="h-2 rounded-full overflow-hidden" style={{ background: '#1f1f24' }}>
              <div
                className="h-full rounded-full transition-all"
                style={{ width: `${op.heat}%`, background: 'linear-gradient(to right, #8a8a96, #f4f4f6)' }}
              />
            </div>
          </div>

          {/* Why now */}
          <div className="rounded-xl p-4" style={{ background: '#18181b', border: '1px solid #1a1a1d' }}>
            <p className="text-[11px] font-bold uppercase tracking-[0.12em] text-white/30 mb-2">Por que agora?</p>
            <p className="text-[13px] text-white/60 leading-relaxed">
              Este tema teve um aumento de <span className="text-white font-semibold">+{Math.round(op.heat * 0.4)}%</span> nas buscas nos ultimos 7 dias. Canais com menos de 100K inscritos estao capturando esse trafico agora. A janela ideal e de <span className="text-white font-semibold">48-72 horas</span>.
            </p>
          </div>

          {/* CTA */}
          <a
            href={`/estudio?q=${encodeURIComponent(op.title)}`}
            className="btn-accent flex items-center justify-center gap-2 h-11 rounded-xl text-[14px] font-extrabold"
          >
            <Zap className="size-4" />
            Criar roteiro agora
            <ArrowRight className="size-4" />
          </a>
        </div>
      </div>
    </Backdrop>
  )
}

/* ─── CALENDAR EVENT MODAL ────────────────────────────────── */
export function CalendarEventModal({ event, onClose }: { event: CalendarEvent; onClose: () => void }) {
  const platformColor = 'rgba(0,0,0,0.6)'
  return (
    <Backdrop onClose={onClose}>
      <div
        className="relative w-[480px] max-w-full rounded-2xl overflow-hidden"
        style={{ background: '#111113', border: '1px solid #1f1f24' }}
      >
        <CloseBtn onClose={onClose} />

        {/* Thumbnail */}
        <div className="relative w-full" style={{ aspectRatio: '16/9' }}>
          <img src={event.thumb} alt={event.title} className="w-full h-full object-cover" crossOrigin="anonymous" />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.75) 0%, transparent 60%)' }} />
          <span
            className="absolute top-3 left-3 text-[10px] font-bold px-2.5 py-1 rounded text-white"
            style={{ background: platformColor }}
          >
            {event.platform}
          </span>
        </div>

        <div className="p-5 flex flex-col gap-4">
          <div>
            <p className="text-[11.5px] text-white/35 mb-1">Publicacao agendada</p>
            <h2 className="text-[17px] font-extrabold text-white tracking-tight leading-snug">{event.title}</h2>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-xl p-3" style={{ background: '#18181b', border: '1px solid #1a1a1d' }}>
              <p className="text-[10.5px] text-white/35 mb-1">Data</p>
              <p className="text-[13.5px] font-bold text-white">{event.day} de junho, 2026</p>
            </div>
            <div className="rounded-xl p-3" style={{ background: '#18181b', border: '1px solid #1a1a1d' }}>
              <p className="text-[10.5px] text-white/35 mb-1">Horario</p>
              <p className="text-[13.5px] font-bold text-white">{event.time}</p>
            </div>
          </div>

          <div className="flex flex-col gap-2 pt-1" style={{ borderTop: '1px solid #1a1a1d' }}>
            <button
              className="btn-accent flex items-center justify-center gap-2 h-10 rounded-xl text-[13px] font-bold"
            >
              <CirclePlay className="size-4" /> Ver video
            </button>
            <div className="flex gap-2">
              <button
                className="flex items-center justify-center gap-2 h-9 rounded-xl text-[12.5px] font-medium text-white/60 flex-1 transition-colors hover:text-white"
                style={{ background: '#18181b', border: '1px solid #1f1f24' }}
              >
                <CalendarDays className="size-3.5" /> Reagendar
              </button>
              <button
                className="flex items-center justify-center gap-2 h-9 rounded-xl text-[12.5px] font-medium text-white/60 flex-1 transition-colors hover:text-white"
                style={{ background: '#18181b', border: '1px solid #1f1f24' }}
              >
                <X className="size-3.5" /> Cancelar
              </button>
            </div>
          </div>
        </div>
      </div>
    </Backdrop>
  )
}

/* ─── SCHEDULE MODAL ──────────────────────────────────────── */
export function ScheduleModal({ onClose }: { onClose: () => void }) {
  return (
    <Backdrop onClose={onClose}>
      <div
        className="relative w-[480px] max-w-full rounded-2xl"
        style={{ background: '#111113', border: '1px solid #1f1f24' }}
      >
        <CloseBtn onClose={onClose} />
        <div className="p-6 flex flex-col gap-5">
          <div>
            <h2 className="text-[19px] font-extrabold text-white tracking-tight">Agendar publicacao</h2>
            <p className="text-[13px] text-white/40 mt-1">Escolha o video, plataforma e horario</p>
          </div>

          {/* Video select */}
          <div>
            <label className="text-[11.5px] font-bold uppercase tracking-[0.12em] text-white/35 block mb-2">Video</label>
            <select
              className="w-full h-10 px-3 rounded-xl text-[13.5px] text-white outline-none"
              style={{ background: '#18181b', border: '1px solid #1f1f24' }}
            >
              <option>Como eu fiz R$50 mil em 30 dias com conteudo</option>
              <option>O setup perfeito para criadores em 2026</option>
              <option>Gravei por 24h em 3 cidades diferentes</option>
            </select>
          </div>

          {/* Platform */}
          <div>
            <label className="text-[11.5px] font-bold uppercase tracking-[0.12em] text-white/35 block mb-2">Plataforma</label>
            <div className="flex gap-2">
              {['YouTube', 'TikTok', 'Instagram'].map((p, i) => (
                <button
                  key={p}
                  className="flex-1 h-9 rounded-xl text-[12.5px] font-bold transition-colors"
                  style={i === 0
                    ? { background: '#f4f4f6', color: '#0a0a0c' }
                    : { background: 'rgba(255,255,255,0.04)', color: 'rgba(255,255,255,0.45)', border: '1px solid rgba(255,255,255,0.08)' }
                  }
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {/* Date + time */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11.5px] font-bold uppercase tracking-[0.12em] text-white/35 block mb-2">Data</label>
              <input
                type="date"
                defaultValue="2026-06-28"
                className="w-full h-10 px-3 rounded-xl text-[13.5px] text-white outline-none"
                style={{ background: '#18181b', border: '1px solid #1f1f24', colorScheme: 'dark' }}
              />
            </div>
            <div>
              <label className="text-[11.5px] font-bold uppercase tracking-[0.12em] text-white/35 block mb-2">Horario</label>
              <input
                type="time"
                defaultValue="12:00"
                className="w-full h-10 px-3 rounded-xl text-[13.5px] text-white outline-none"
                style={{ background: '#18181b', border: '1px solid #1f1f24', colorScheme: 'dark' }}
              />
            </div>
          </div>

          <button
            onClick={onClose}
            className="btn-accent flex items-center justify-center gap-2 h-11 rounded-xl text-[14px] font-extrabold"
          >
            <Check className="size-4" />
            Confirmar agendamento
          </button>
        </div>
      </div>
    </Backdrop>
  )
}

/* ─── WHATSAPP MODAL ──────────────────────────────────────── */
export function WhatsAppModal({ onClose }: { onClose: () => void }) {
  return (
    <Backdrop onClose={onClose}>
      <div
        className="relative w-[420px] max-w-full rounded-2xl"
        style={{ background: '#111113', border: '1px solid #1f1f24' }}
      >
        <CloseBtn onClose={onClose} />
        <div className="p-6 flex flex-col gap-5">
          <div className="flex items-center gap-3">
            <div className="size-11 rounded-2xl flex items-center justify-center" style={{ background: 'rgba(37,211,102,0.12)', border: '1px solid rgba(37,211,102,0.2)' }}>
              <Bell className="size-5" style={{ color: '#25d366' }} />
            </div>
            <div>
              <h2 className="text-[18px] font-extrabold text-white tracking-tight">Alertas por WhatsApp</h2>
              <p className="text-[12.5px] text-white/40">Receba avisos quando a IA detectar oportunidades</p>
            </div>
          </div>

          <div className="rounded-xl p-4 flex flex-col gap-3" style={{ background: '#18181b', border: '1px solid #1a1a1d' }}>
            {[
              'Oportunidade detectada no seu nicho',
              'Melhor horario para postar hoje',
              'Video pronto para publicar',
              'Atualizacao semanal do canal',
            ].map((item) => (
              <div key={item} className="flex items-center gap-3">
                <Check className="size-3.5 flex-shrink-0" style={{ color: '#25d366' }} />
                <span className="text-[13px] text-white/65">{item}</span>
              </div>
            ))}
          </div>

          <div>
            <label className="text-[11.5px] font-bold uppercase tracking-[0.12em] text-white/35 block mb-2">Seu WhatsApp</label>
            <div className="flex gap-2">
              <div
                className="flex items-center px-3 rounded-xl text-[13.5px] text-white/50 flex-shrink-0"
                style={{ background: '#18181b', border: '1px solid #1f1f24' }}
              >
                +55
              </div>
              <input
                type="tel"
                placeholder="(11) 9 0000-0000"
                className="flex-1 h-10 px-3 rounded-xl text-[13.5px] text-white placeholder:text-white/30 outline-none"
                style={{ background: '#18181b', border: '1px solid #1f1f24' }}
              />
            </div>
          </div>

          <button
            onClick={onClose}
            className="flex items-center justify-center gap-2 h-11 rounded-xl text-[14px] font-extrabold text-white transition-opacity hover:opacity-90"
            style={{ background: '#25d366', color: '#000' }}
          >
            <Check className="size-4" />
            Ativar alertas
          </button>
        </div>
      </div>
    </Backdrop>
  )
}
