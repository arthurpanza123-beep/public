import { AppSidebar } from '@/components/app-sidebar'
import { Topbar } from '@/components/topbar'
import { AppBackground } from '@/components/app-background'
import { OnboardingGate } from '@/components/onboarding/onboarding-gate'
import { OnboardingResumeBanner } from '@/components/onboarding/onboarding-resume-banner'

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <OnboardingGate>
      <AppBackground />
      <div className="relative z-10 flex min-h-screen">
        <AppSidebar />
        <div className="flex-1 ml-[216px]">
          <Topbar />
          <main className="pt-[52px]">
            <div className="px-8 pt-5">
              <OnboardingResumeBanner />
            </div>
            {children}
          </main>
        </div>
      </div>
    </OnboardingGate>
  )
}
