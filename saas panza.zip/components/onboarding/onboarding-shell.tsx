'use client'

import { OnboardingProgress } from './onboarding-progress'
import { OnboardingBackground } from './onboarding-background'

export function OnboardingShell({
  step,
  total,
  showProgress = true,
  onContinueLater,
  transitionKey,
  children,
}: {
  step: number
  total: number
  showProgress?: boolean
  onContinueLater?: () => void
  /** muda a cada etapa para reiniciar a transição de entrada */
  transitionKey: string | number
  children: React.ReactNode
}) {
  return (
    <div className="relative flex min-h-[100dvh] flex-col bg-[#050505]">
      <OnboardingBackground />

      {/* Top bar */}
      <header className="relative z-10 flex items-center gap-4 px-5 py-4 sm:px-8 sm:py-5">
        <div className="flex items-center">
          <img src="/panza-p.png" alt="Panza" className="h-8 w-8 object-contain" />
        </div>

        {showProgress ? (
          <div className="mx-auto hidden w-full max-w-[260px] sm:block">
            <OnboardingProgress step={step} total={total} />
          </div>
        ) : (
          <div className="mx-auto" />
        )}

        {onContinueLater ? (
          <button
            type="button"
            onClick={onContinueLater}
            className="ml-auto text-[12.5px] font-medium text-[#6e6e73] transition-colors hover:text-[#a1a1a6]"
          >
            Continuar depois
          </button>
        ) : (
          <div className="ml-auto w-px" />
        )}
      </header>

      {/* Mobile progress */}
      {showProgress ? (
        <div className="relative z-10 px-5 pb-2 sm:hidden">
          <OnboardingProgress step={step} total={total} />
        </div>
      ) : null}

      {/* Content */}
      <main className="relative z-10 flex flex-1 items-start justify-center px-5 pb-32 pt-6 sm:items-center sm:px-8 sm:pb-12 sm:pt-0">
        <div
          key={transitionKey}
          className="onboarding-step glass-panel w-full max-w-[600px] rounded-3xl p-6 sm:p-9"
        >
          {children}
        </div>
      </main>
    </div>
  )
}
