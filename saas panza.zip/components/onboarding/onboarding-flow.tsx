'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import type { ContentType, OnboardingProfile } from '@/lib/onboarding-types'
import { DEFAULT_WORKFLOW_STAGES, TOTAL_STEPS, routeForGoal } from '@/lib/onboarding-options'
import {
  clearDraft,
  completeOnboarding,
  deferOnboarding,
  loadDraft,
  loadProfile,
  saveDraft,
} from '@/lib/profile-store'
import { OnboardingShell } from './onboarding-shell'
import { OnboardingNavigation } from './onboarding-navigation'
import type { StepProps } from './step-props'
import { WelcomeStep } from './steps/welcome-step'
import { ProfileStep } from './steps/profile-step'
import { OperationStep } from './steps/operation-step'
import { GoalsStep } from './steps/goals-step'
import { ContentTypesStep } from './steps/content-types-step'
import { RhythmStep } from './steps/rhythm-step'
import { WorkflowStep } from './steps/workflow-step'
import { RoutineStep } from './steps/routine-step'
import { PreferencesStep } from './steps/preferences-step'
import { SummaryStep } from './steps/summary-step'

type Draft = Partial<OnboardingProfile>

const DEFAULT_DATA: Draft = {
  displayName: '',
  role: '',
  goals: [],
  primaryGoal: '',
  contentTypeIds: [],
  weeklyVolume: '',
  publishingDays: [],
  workflowStages: DEFAULT_WORKFLOW_STAGES,
  recurringTaskIds: [],
  taskRecurrence: 'workdays',
  showOverdueHighlights: true,
  taskVisibility: 'today',
}

/** validação mínima por etapa; retorna mensagem de erro ou null */
function validateStep(step: number, data: Draft): string | null {
  switch (step) {
    case 1:
      return data.displayName?.trim() ? null : 'Informe como devemos chamar você.'
    case 2:
      return data.operationType ? null : 'Escolha uma opção.'
    case 3:
      return (data.goals?.length ?? 0) > 0 ? null : 'Escolha ao menos um objetivo.'
    case 4:
      return (data.contentTypeIds?.length ?? 0) > 0 ? null : 'Escolha ao menos um tipo de conteúdo.'
    case 5:
      return data.weeklyVolume ? null : 'Escolha seu ritmo de produção.'
    case 6:
      return (data.workflowStages ?? []).some((s) => s.enabled) ? null : 'Mantenha ao menos uma etapa ativa.'
    default:
      return null
  }
}

export function OnboardingFlow() {
  const router = useRouter()
  const [step, setStep] = useState(0)
  const [data, setData] = useState<Draft>(DEFAULT_DATA)
  const [customContentTypes, setCustomContentTypes] = useState<ContentType[]>([])
  const [showErrors, setShowErrors] = useState(false)
  const [hydrated, setHydrated] = useState(false)
  const completingRef = useRef(false)

  // Retomar rascunho / redirecionar se já concluído
  useEffect(() => {
    const profile = loadProfile()
    if (profile?.onboardingCompleted) {
      router.replace(profile.defaultHomeRoute || '/')
      return
    }
    const draft = loadDraft()
    if (draft) {
      setData({ ...DEFAULT_DATA, ...draft.data })
      setCustomContentTypes(draft.customContentTypes ?? [])
      setStep(Math.min(draft.step, TOTAL_STEPS - 1))
    }
    setHydrated(true)
  }, [router])

  // Persistir rascunho a cada mudança
  useEffect(() => {
    if (!hydrated) return
    saveDraft({ step, data, customContentTypes, updatedAt: new Date().toISOString() })
  }, [step, data, customContentTypes, hydrated])

  const update = useCallback((patch: Draft) => {
    setData((prev) => ({ ...prev, ...patch }))
  }, [])

  const goNext = useCallback(() => {
    const err = validateStep(step, data)
    if (err) {
      setShowErrors(true)
      return
    }
    setShowErrors(false)
    setStep((s) => Math.min(s + 1, TOTAL_STEPS - 1))
  }, [step, data])

  const goBack = useCallback(() => {
    setShowErrors(false)
    setStep((s) => Math.max(s - 1, 0))
  }, [])

  const finish = useCallback(() => {
    if (completingRef.current) return
    completingRef.current = true
    const profile = completeOnboarding({
      profile: {
        displayName: data.displayName!.trim(),
        professionalName: data.professionalName?.trim() || undefined,
        role: data.role || 'Outro',
        operationType: data.operationType ?? 'solo',
        teamSize: data.teamSize,
        teamRoles: data.teamRoles,
        goals: data.goals ?? [],
        primaryGoal: data.primaryGoal ?? (data.goals?.[0] ?? 'produce_today'),
        contentTypeIds: data.contentTypeIds ?? [],
        weeklyVolume: data.weeklyVolume ?? '',
        publishingDays: data.publishingDays ?? [],
        workflowStages: data.workflowStages ?? DEFAULT_WORKFLOW_STAGES,
        recurringTaskIds: data.recurringTaskIds ?? [],
        taskRecurrence: data.taskRecurrence ?? 'workdays',
        workdayStart: data.workdayStart,
        workdayEnd: data.workdayEnd,
        dailyReviewTime: data.dailyReviewTime,
        showOverdueHighlights: data.showOverdueHighlights ?? true,
        taskVisibility: data.taskVisibility ?? 'today',
      },
      customContentTypes,
    })
    toast.success('Tudo pronto. A Panza foi preparada para você.')
    router.push(profile.defaultHomeRoute || routeForGoal(profile.primaryGoal))
  }, [data, customContentTypes, router])

  const continueLater = useCallback(() => {
    deferOnboarding({
      displayName: data.displayName?.trim() ?? '',
      professionalName: data.professionalName?.trim() || undefined,
      role: data.role ?? '',
    })
    saveDraft({ step, data, customContentTypes, updatedAt: new Date().toISOString() })
    toast('Você pode continuar pelas Configurações quando quiser.')
    router.push('/')
  }, [data, customContentTypes, step, router])

  const stepProps: StepProps = {
    data,
    update,
    customContentTypes,
    setCustomContentTypes,
    goNext,
    showErrors,
  }

  const isWelcome = step === 0
  const isSummary = step === TOTAL_STEPS - 1

  const stepNode = (() => {
    switch (step) {
      case 0:
        return <WelcomeStep />
      case 1:
        return <ProfileStep {...stepProps} />
      case 2:
        return <OperationStep {...stepProps} />
      case 3:
        return <GoalsStep {...stepProps} />
      case 4:
        return <ContentTypesStep {...stepProps} />
      case 5:
        return <RhythmStep {...stepProps} />
      case 6:
        return <WorkflowStep {...stepProps} />
      case 7:
        return <RoutineStep {...stepProps} />
      case 8:
        return <PreferencesStep {...stepProps} />
      case 9:
        return <SummaryStep {...stepProps} />
      default:
        return null
    }
  })()

  if (!hydrated) {
    return <div className="min-h-[100dvh] bg-[#050505]" />
  }

  return (
    <OnboardingShell
      step={step}
      total={TOTAL_STEPS}
      showProgress={!isWelcome}
      onContinueLater={!isWelcome ? continueLater : undefined}
      transitionKey={step}
    >
      <div className="flex flex-col gap-8">
        {stepNode}
        <OnboardingNavigation
          onBack={goBack}
          onNext={isSummary ? finish : goNext}
          backVisible={!isWelcome}
          nextLabel={isWelcome ? 'Começar' : isSummary ? 'Entrar na Panza' : 'Continuar'}
        />
      </div>
    </OnboardingShell>
  )
}
