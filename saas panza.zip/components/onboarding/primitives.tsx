'use client'

import { Check, GripVertical, type LucideIcon } from 'lucide-react'
import { cn } from '@/lib/utils'

/* ------------------------------------------------------------------ */
/* StepHeader                                                          */
/* ------------------------------------------------------------------ */

export function StepHeader({
  title,
  description,
}: {
  title: string
  description?: string
}) {
  return (
    <div className="flex flex-col gap-2.5">
      <h1 className="text-[26px] sm:text-[32px] font-extrabold text-[#f5f5f7] tracking-tight leading-[1.1] text-balance">
        {title}
      </h1>
      {description ? (
        <p className="text-[14px] sm:text-[15px] text-[#a1a1a6] leading-relaxed text-pretty max-w-[480px]">
          {description}
        </p>
      ) : null}
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* TextField                                                           */
/* ------------------------------------------------------------------ */

export function TextField({
  id,
  label,
  value,
  onChange,
  placeholder,
  error,
  autoFocus,
  optional,
  onEnter,
}: {
  id: string
  label: string
  value: string
  onChange: (v: string) => void
  placeholder?: string
  error?: string
  autoFocus?: boolean
  optional?: boolean
  onEnter?: () => void
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-[12.5px] font-semibold text-[#a1a1a6] flex items-center gap-1.5">
        {label}
        {optional ? <span className="text-[11px] font-normal text-[#6e6e73]">(opcional)</span> : null}
      </label>
      <input
        id={id}
        type="text"
        value={value}
        autoFocus={autoFocus}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && onEnter) {
            e.preventDefault()
            onEnter()
          }
        }}
        aria-invalid={Boolean(error)}
        className={cn(
          'h-11 w-full rounded-md bg-[#101010] px-3.5 text-[14.5px] text-[#f5f5f7] placeholder:text-[#5a5a63] outline-none transition-colors',
          'border focus:border-[rgba(255,255,255,0.45)]',
          error ? 'border-[#fb2c36]' : 'border-[rgba(255,255,255,0.12)]',
        )}
      />
      {error ? <p className="text-[12px] text-[#fb2c36] mt-0.5">{error}</p> : null}
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* SelectableCard — escolha única                                      */
/* ------------------------------------------------------------------ */

export function SelectableCard({
  selected,
  onSelect,
  title,
  description,
  icon: Icon,
  compact,
}: {
  selected: boolean
  onSelect: () => void
  title: string
  description?: string
  icon?: LucideIcon
  compact?: boolean
}) {
  return (
    <button
      type="button"
      role="radio"
      aria-checked={selected}
      onClick={onSelect}
      className={cn(
        'group relative flex w-full items-center gap-3 rounded-md border text-left transition-all duration-150',
        compact ? 'px-3.5 py-3' : 'px-4 py-4',
        selected
          ? 'border-[rgba(255,255,255,0.55)] bg-[rgba(255,255,255,0.06)]'
          : 'border-[rgba(255,255,255,0.1)] bg-[#101010] hover:border-[rgba(255,255,255,0.22)] hover:bg-[#161616]',
      )}
    >
      {Icon ? (
        <span
          className={cn(
            'flex size-9 shrink-0 items-center justify-center rounded-md border transition-colors',
            selected ? 'border-[rgba(255,255,255,0.3)] bg-[rgba(255,255,255,0.1)]' : 'border-[rgba(255,255,255,0.08)] bg-[#161616]',
          )}
        >
          <Icon className="size-4 text-[#f5f5f7]" strokeWidth={1.9} />
        </span>
      ) : null}
      <span className="flex min-w-0 flex-col">
        <span className="text-[14px] font-semibold text-[#f5f5f7] leading-snug">{title}</span>
        {description ? <span className="text-[12.5px] text-[#a1a1a6] leading-snug mt-0.5">{description}</span> : null}
      </span>
      <span
        className={cn(
          'ml-auto flex size-5 shrink-0 items-center justify-center rounded-full border transition-all',
          selected ? 'border-[#f5f5f7] bg-[#f5f5f7]' : 'border-[rgba(255,255,255,0.2)]',
        )}
      >
        {selected ? <Check className="size-3 text-[#050505]" strokeWidth={3} /> : null}
      </span>
    </button>
  )
}

/* ------------------------------------------------------------------ */
/* MultiSelectCard — múltipla escolha                                  */
/* ------------------------------------------------------------------ */

export function MultiSelectCard({
  selected,
  onToggle,
  label,
  disabled,
}: {
  selected: boolean
  onToggle: () => void
  label: string
  disabled?: boolean
}) {
  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={selected}
      disabled={disabled && !selected}
      onClick={onToggle}
      className={cn(
        'group flex items-center gap-2.5 rounded-md border px-3.5 py-3 text-left transition-all duration-150',
        selected
          ? 'border-[rgba(255,255,255,0.55)] bg-[rgba(255,255,255,0.06)]'
          : 'border-[rgba(255,255,255,0.1)] bg-[#101010] hover:border-[rgba(255,255,255,0.22)] hover:bg-[#161616]',
        disabled && !selected ? 'cursor-not-allowed opacity-40 hover:border-[rgba(255,255,255,0.1)] hover:bg-[#101010]' : '',
      )}
    >
      <span
        className={cn(
          'flex size-[18px] shrink-0 items-center justify-center rounded border transition-all',
          selected ? 'border-[#f5f5f7] bg-[#f5f5f7]' : 'border-[rgba(255,255,255,0.25)]',
        )}
      >
        {selected ? <Check className="size-3 text-[#050505]" strokeWidth={3} /> : null}
      </span>
      <span className="text-[13.5px] font-medium text-[#f5f5f7]">{label}</span>
    </button>
  )
}

/* ------------------------------------------------------------------ */
/* Chip — botão compacto (dias da semana)                              */
/* ------------------------------------------------------------------ */

export function Chip({
  selected,
  onToggle,
  children,
  ariaLabel,
}: {
  selected: boolean
  onToggle: () => void
  children: React.ReactNode
  ariaLabel?: string
}) {
  return (
    <button
      type="button"
      aria-pressed={selected}
      aria-label={ariaLabel}
      onClick={onToggle}
      className={cn(
        'h-10 min-w-[52px] rounded-md border px-3 text-[13px] font-semibold transition-all duration-150',
        selected
          ? 'border-[rgba(255,255,255,0.55)] bg-[rgba(255,255,255,0.08)] text-[#f5f5f7]'
          : 'border-[rgba(255,255,255,0.1)] bg-[#101010] text-[#a1a1a6] hover:border-[rgba(255,255,255,0.22)] hover:text-[#f5f5f7]',
      )}
    >
      {children}
    </button>
  )
}

/* ------------------------------------------------------------------ */
/* WorkflowStageRow                                                    */
/* ------------------------------------------------------------------ */

export function WorkflowStageRow({
  label,
  enabled,
  onToggle,
  onMoveUp,
  onMoveDown,
  canMoveUp,
  canMoveDown,
  onRename,
}: {
  label: string
  enabled: boolean
  onToggle: () => void
  onMoveUp: () => void
  onMoveDown: () => void
  canMoveUp: boolean
  canMoveDown: boolean
  onRename: (v: string) => void
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-2 rounded-md border px-2.5 py-2 transition-colors',
        enabled ? 'border-[rgba(255,255,255,0.14)] bg-[#101010]' : 'border-[rgba(255,255,255,0.07)] bg-[#0c0c0c] opacity-60',
      )}
    >
      <div className="flex flex-col -my-1">
        <button
          type="button"
          onClick={onMoveUp}
          disabled={!canMoveUp}
          aria-label="Mover para cima"
          className="px-1 text-[#6e6e73] hover:text-[#f5f5f7] disabled:opacity-25"
        >
          <span className="block text-[10px] leading-none">▲</span>
        </button>
        <button
          type="button"
          onClick={onMoveDown}
          disabled={!canMoveDown}
          aria-label="Mover para baixo"
          className="px-1 text-[#6e6e73] hover:text-[#f5f5f7] disabled:opacity-25"
        >
          <span className="block text-[10px] leading-none">▼</span>
        </button>
      </div>
      <GripVertical className="size-4 text-[#3a3a42] shrink-0" />
      <input
        value={label}
        onChange={(e) => onRename(e.target.value)}
        aria-label="Nome da etapa"
        className="flex-1 bg-transparent text-[13.5px] font-medium text-[#f5f5f7] outline-none"
      />
      <button
        type="button"
        role="switch"
        aria-checked={enabled}
        onClick={onToggle}
        aria-label={enabled ? 'Desativar etapa' : 'Ativar etapa'}
        className={cn(
          'relative h-5 w-9 shrink-0 rounded-full transition-colors',
          enabled ? 'bg-[#f5f5f7]' : 'bg-[rgba(255,255,255,0.15)]',
        )}
      >
        <span
          className={cn(
            'absolute top-0.5 size-4 rounded-full transition-all',
            enabled ? 'left-[18px] bg-[#050505]' : 'left-0.5 bg-[#a1a1a6]',
          )}
        />
      </button>
    </div>
  )
}
