'use client'

export function OnboardingProgress({ step, total }: { step: number; total: number }) {
  const pct = Math.round(((step + 1) / total) * 100)
  return (
    <div className="flex items-center gap-3" aria-hidden>
      <div className="h-[3px] flex-1 overflow-hidden rounded-full bg-[rgba(255,255,255,0.09)]">
        <div
          className="h-full rounded-full bg-[#f5f5f7] transition-[width] duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]"
          style={{ width: `${pct}%` }}
        />
      </div>
      <span className="text-[11.5px] font-medium tabular-nums text-[#6e6e73]">
        {step + 1} / {total}
      </span>
    </div>
  )
}
