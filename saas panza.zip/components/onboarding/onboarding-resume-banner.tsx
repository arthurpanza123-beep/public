'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Sparkles, X, ChevronRight } from 'lucide-react'
import { isLegacyUserPending, loadDraft, loadProfile } from '@/lib/profile-store'

const DISMISS_KEY = 'panza:onboarding-banner-dismissed'

/**
 * Lembrete discreto para personalizar a Panza. Aparece para quem adiou o
 * onboarding ou para usuários antigos com dados — nunca após concluído e não
 * em todas as visitas (pode ser dispensado).
 */
export function OnboardingResumeBanner() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const profile = loadProfile()
    if (profile?.onboardingCompleted) return
    if (sessionStorage.getItem(DISMISS_KEY)) return
    const hasDraft = Boolean(loadDraft())
    if (isLegacyUserPending() || hasDraft) setVisible(true)
  }, [])

  if (!visible) return null

  const hasDraft = Boolean(loadDraft())

  return (
    <div
      className="flex items-center gap-3 rounded-lg px-4 py-3"
      style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)' }}
    >
      <div className="flex size-8 shrink-0 items-center justify-center rounded-md" style={{ background: 'rgba(255,255,255,0.06)' }}>
        <Sparkles className="size-4 text-[#f5f5f7]" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-[13px] font-bold text-[#f5f5f7]">Personalizar minha Panza</p>
        <p className="text-[11.5px] text-white/45">
          {hasDraft ? 'Você tem uma personalização em andamento.' : 'Adapte o sistema ao seu fluxo de produção.'}
        </p>
      </div>
      <Link
        href="/onboarding"
        className="flex h-8 items-center gap-1 rounded-md px-3 text-[12px] font-bold text-[#050505] transition-colors"
        style={{ background: '#f5f5f7' }}
      >
        {hasDraft ? 'Continuar' : 'Começar'}
        <ChevronRight className="size-3.5" />
      </Link>
      <button
        type="button"
        onClick={() => {
          sessionStorage.setItem(DISMISS_KEY, '1')
          setVisible(false)
        }}
        aria-label="Dispensar"
        className="flex size-7 items-center justify-center rounded-md text-white/40 transition-colors hover:bg-white/[0.06] hover:text-white"
      >
        <X className="size-4" />
      </button>
    </div>
  )
}
