'use client'

import { useEffect, useRef } from 'react'

/**
 * Fundo dinâmico estilo Apple/Gemini: orbs de aurora em movimento contínuo +
 * um brilho de vidro que segue o cursor com parallax suave. Paleta neutra
 * (brancos/cinzas) para manter a estética sóbria do app.
 */
export function OnboardingBackground() {
  const rootRef = useRef<HTMLDivElement>(null)
  const glowRef = useRef<HTMLDivElement>(null)
  const layerRef = useRef<HTMLDivElement>(null)
  const raf = useRef<number | null>(null)
  // posição alvo (mouse) e atual (interpolada) em 0..1
  const target = useRef({ x: 0.5, y: 0.35 })
  const current = useRef({ x: 0.5, y: 0.35 })

  useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduce) return

    const onPointerMove = (e: PointerEvent) => {
      target.current.x = e.clientX / window.innerWidth
      target.current.y = e.clientY / window.innerHeight
    }

    const tick = () => {
      // interpolação (easing) para um movimento fluido tipo "líquido"
      current.current.x += (target.current.x - current.current.x) * 0.06
      current.current.y += (target.current.y - current.current.y) * 0.06
      const { x, y } = current.current

      if (glowRef.current) {
        glowRef.current.style.transform = `translate3d(${x * 100}vw, ${y * 100}vh, 0) translate(-50%, -50%)`
      }
      if (layerRef.current) {
        // parallax sutil das orbs no sentido oposto ao cursor
        const px = (x - 0.5) * -36
        const py = (y - 0.5) * -36
        layerRef.current.style.transform = `translate3d(${px}px, ${py}px, 0)`
      }
      raf.current = requestAnimationFrame(tick)
    }

    window.addEventListener('pointermove', onPointerMove, { passive: true })
    raf.current = requestAnimationFrame(tick)

    return () => {
      window.removeEventListener('pointermove', onPointerMove)
      if (raf.current) cancelAnimationFrame(raf.current)
    }
  }, [])

  return (
    <div
      ref={rootRef}
      aria-hidden="true"
      className="noise pointer-events-none absolute inset-0 overflow-hidden"
    >
      {/* base vignette */}
      <div className="absolute inset-0 bg-[#050505]" />

      {/* orbs de aurora em parallax */}
      <div ref={layerRef} className="absolute inset-0 will-change-transform">
        <div
          className="aurora-orb aurora-a"
          style={{
            top: '-14%',
            left: '4%',
            width: '48vw',
            height: '48vw',
            background:
              'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.40), rgba(255,255,255,0) 70%)',
          }}
        />
        <div
          className="aurora-orb aurora-b"
          style={{
            top: '14%',
            right: '-8%',
            width: '44vw',
            height: '44vw',
            background:
              'radial-gradient(circle at 50% 50%, rgba(120,150,205,0.34), rgba(120,150,205,0) 70%)',
          }}
        />
        <div
          className="aurora-orb aurora-c"
          style={{
            bottom: '-20%',
            left: '24%',
            width: '56vw',
            height: '56vw',
            background:
              'radial-gradient(circle at 50% 50%, rgba(110,120,140,0.40), rgba(110,120,140,0) 72%)',
          }}
        />
      </div>

      {/* brilho que segue o cursor */}
      <div
        ref={glowRef}
        className="absolute left-0 top-0 h-[520px] w-[520px] rounded-full"
        style={{
          background:
            'radial-gradient(circle, rgba(255,255,255,0.16), rgba(200,215,255,0.06) 45%, rgba(255,255,255,0) 65%)',
          transform: 'translate3d(50vw, 35vh, 0) translate(-50%, -50%)',
        }}
      />

      {/* leve escurecimento nas bordas para legibilidade */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(125% 125% at 50% 38%, rgba(5,5,5,0) 45%, rgba(5,5,5,0.45) 100%)',
        }}
      />
    </div>
  )
}
