'use client'

import { ArrowLeft, ArrowRight } from 'lucide-react'
import { cn } from '@/lib/utils'

export function OnboardingNavigation({
  onBack,
  onNext,
  nextLabel = 'Continuar',
  backVisible = true,
  nextDisabled = false,
  onSkip,
  skipLabel,
}: {
  onBack: () => void
  onNext: () => void
  nextLabel?: string
  backVisible?: boolean
  nextDisabled?: boolean
  onSkip?: () => void
  skipLabel?: string
}) {
  return (
    <div className="flex items-center gap-3">
      {backVisible ? (
        <button
          type="button"
          onClick={onBack}
          className="flex h-11 items-center gap-2 rounded-md border border-[rgba(255,255,255,0.12)] px-4 text-[13.5px] font-semibold text-[#a1a1a6] transition-colors hover:border-[rgba(255,255,255,0.25)] hover:text-[#f5f5f7]"
        >
          <ArrowLeft className="size-4" />
          <span className="hidden sm:inline">Voltar</span>
        </button>
      ) : null}

      {onSkip ? (
        <button
          type="button"
          onClick={onSkip}
          className="h-11 px-2 text-[13px] font-medium text-[#6e6e73] transition-colors hover:text-[#a1a1a6]"
        >
          {skipLabel ?? 'Pular'}
        </button>
      ) : null}

      <button
        type="button"
        onClick={onNext}
        disabled={nextDisabled}
        className={cn(
          'ml-auto flex h-11 items-center gap-2 rounded-md px-6 text-[13.5px] font-bold transition-all duration-150',
          nextDisabled
            ? 'cursor-not-allowed bg-[rgba(255,255,255,0.08)] text-[#5a5a63]'
            : 'bg-[#f5f5f7] text-[#050505] hover:bg-white',
        )}
      >
        {nextLabel}
        <ArrowRight className="size-4" strokeWidth={2.4} />
      </button>
    </div>
  )
}
