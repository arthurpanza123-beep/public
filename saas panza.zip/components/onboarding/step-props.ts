import type { ContentType, OnboardingProfile } from '@/lib/onboarding-types'

export type StepProps = {
  data: Partial<OnboardingProfile>
  update: (patch: Partial<OnboardingProfile>) => void
  customContentTypes: ContentType[]
  setCustomContentTypes: (types: ContentType[]) => void
  /** avança a etapa (usado para Enter em campos de texto) */
  goNext: () => void
  /** true quando o usuário tentou avançar; usado para revelar erros */
  showErrors: boolean
}
