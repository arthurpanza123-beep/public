'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { ensureSchema, shouldShowOnboarding } from '@/lib/profile-store'

/**
 * Em uma instalação vazia, redireciona para o onboarding antes de mostrar a
 * interface principal. Usuários com dados ou que adiaram não são forçados.
 */
export function OnboardingGate({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const [checked, setChecked] = useState(false)

  useEffect(() => {
    ensureSchema()
    if (shouldShowOnboarding()) {
      router.replace('/onboarding')
      return
    }
    setChecked(true)
  }, [router])

  if (!checked) {
    return <div className="min-h-[100dvh] bg-[#080809]" />
  }

  return <>{children}</>
}
