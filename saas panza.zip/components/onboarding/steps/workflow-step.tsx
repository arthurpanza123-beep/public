'use client'

import { useState } from 'react'
import { Plus } from 'lucide-react'
import { DEFAULT_WORKFLOW_STAGES } from '@/lib/onboarding-options'
import type { OnboardingWorkflowStage } from '@/lib/onboarding-types'
import { StepHeader, WorkflowStageRow } from '../primitives'
import type { StepProps } from '../step-props'

export function WorkflowStep({ data, update, showErrors }: StepProps) {
  const [input, setInput] = useState('')
  const stages: OnboardingWorkflowStage[] = data.workflowStages ?? DEFAULT_WORKFLOW_STAGES
  const enabledCount = stages.filter((s) => s.enabled).length
  const error = showErrors && enabledCount === 0 ? 'Mantenha ao menos uma etapa ativa.' : undefined

  function set(next: OnboardingWorkflowStage[]) {
    update({ workflowStages: next })
  }

  function toggle(id: string) {
    set(stages.map((s) => (s.id === id ? { ...s, enabled: !s.enabled } : s)))
  }

  function rename(id: string, label: string) {
    set(stages.map((s) => (s.id === id ? { ...s, label } : s)))
  }

  function move(index: number, dir: -1 | 1) {
    const target = index + dir
    if (target < 0 || target >= stages.length) return
    const next = [...stages]
    ;[next[index], next[target]] = [next[target], next[index]]
    set(next)
  }

  function addStage() {
    const label = input.trim()
    if (!label) return
    const id = 'custom_' + Date.now().toString(36)
    set([...stages, { id, label, enabled: true, custom: true }])
    setInput('')
  }

  return (
    <div className="flex flex-col gap-6">
      <StepHeader
        title="Como o conteúdo passa pela sua produção?"
        description="Ative, reordene ou renomeie as etapas do seu fluxo."
      />

      <div className="flex flex-col gap-2">
        {stages.map((stage, i) => (
          <WorkflowStageRow
            key={stage.id}
            label={stage.label}
            enabled={stage.enabled}
            onToggle={() => toggle(stage.id)}
            onRename={(v) => rename(stage.id, v)}
            onMoveUp={() => move(i, -1)}
            onMoveDown={() => move(i, 1)}
            canMoveUp={i > 0}
            canMoveDown={i < stages.length - 1}
          />
        ))}
      </div>

      <div className="flex items-center gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault()
              addStage()
            }
          }}
          placeholder="Adicionar etapa personalizada"
          aria-label="Adicionar etapa personalizada"
          className="h-10 flex-1 rounded-md border border-[rgba(255,255,255,0.12)] bg-[#101010] px-3.5 text-[13.5px] text-[#f5f5f7] placeholder:text-[#5a5a63] outline-none focus:border-[rgba(255,255,255,0.45)]"
        />
        <button
          type="button"
          onClick={addStage}
          disabled={!input.trim()}
          className="flex h-10 items-center gap-1.5 rounded-md border border-[rgba(255,255,255,0.12)] px-3.5 text-[13px] font-semibold text-[#f5f5f7] transition-colors hover:border-[rgba(255,255,255,0.3)] disabled:opacity-40"
        >
          <Plus className="size-4" />
          Adicionar
        </button>
      </div>

      {error ? <p className="text-[12px] text-[#fb2c36]">{error}</p> : null}
    </div>
  )
}
