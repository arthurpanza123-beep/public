'use client'

import { WEEKDAYS, WEEKLY_VOLUME_OPTIONS } from '@/lib/onboarding-options'
import { Chip, SelectableCard, StepHeader } from '../primitives'
import type { StepProps } from '../step-props'

export function RhythmStep({ data, update }: StepProps) {
  const days = data.publishingDays ?? []

  function toggleDay(value: number) {
    const next = days.includes(value) ? days.filter((d) => d !== value) : [...days, value]
    update({ publishingDays: next })
  }

  return (
    <div className="flex flex-col gap-6">
      <StepHeader title="Quantos conteúdos você costuma produzir por semana?" />

      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {WEEKLY_VOLUME_OPTIONS.map((v) => (
          <SelectableCard
            key={v}
            compact
            selected={data.weeklyVolume === v}
            onSelect={() => update({ weeklyVolume: v })}
            title={v}
          />
        ))}
      </div>

      <div className="flex flex-col gap-3 pt-1">
        <p className="text-[13.5px] font-semibold text-[#f5f5f7]">Em quais dias você normalmente publica?</p>
        <div className="flex flex-wrap gap-2">
          {WEEKDAYS.map((d) => (
            <Chip key={d.value} selected={days.includes(d.value)} onToggle={() => toggleDay(d.value)} ariaLabel={d.label}>
              {d.short}
            </Chip>
          ))}
        </div>
      </div>
    </div>
  )
}
