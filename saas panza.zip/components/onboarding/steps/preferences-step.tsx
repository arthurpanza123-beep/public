'use client'

import type { TaskVisibility } from '@/lib/onboarding-types'
import { SelectableCard, StepHeader } from '../primitives'
import type { StepProps } from '../step-props'
import { cn } from '@/lib/utils'

function TimeField({
  id,
  label,
  value,
  onChange,
}: {
  id: string
  label: string
  value: string
  onChange: (v: string) => void
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-[12.5px] font-semibold text-[#a1a1a6]">
        {label}
      </label>
      <input
        id={id}
        type="time"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-11 w-full rounded-md border border-[rgba(255,255,255,0.12)] bg-[#101010] px-3.5 text-[14px] text-[#f5f5f7] outline-none focus:border-[rgba(255,255,255,0.45)] [color-scheme:dark]"
      />
    </div>
  )
}

function ToggleRow({
  label,
  description,
  checked,
  onToggle,
}: {
  label: string
  description: string
  checked: boolean
  onToggle: () => void
}) {
  return (
    <div className="flex items-center gap-3 rounded-md border border-[rgba(255,255,255,0.1)] bg-[#101010] px-4 py-3.5">
      <div className="flex-1">
        <p className="text-[13.5px] font-semibold text-[#f5f5f7]">{label}</p>
        <p className="text-[12px] text-[#a1a1a6] mt-0.5">{description}</p>
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        onClick={onToggle}
        className={cn(
          'relative h-6 w-11 shrink-0 rounded-full transition-colors',
          checked ? 'bg-[#f5f5f7]' : 'bg-[rgba(255,255,255,0.15)]',
        )}
      >
        <span
          className={cn(
            'absolute top-0.5 size-5 rounded-full transition-all',
            checked ? 'left-[22px] bg-[#050505]' : 'left-0.5 bg-[#a1a1a6]',
          )}
        />
      </button>
    </div>
  )
}

export function PreferencesStep({ data, update }: StepProps) {
  const visibility = data.taskVisibility ?? 'today'

  return (
    <div className="flex flex-col gap-6">
      <StepHeader title="Como você prefere começar o dia?" description="Ajustes finos para a interface se adaptar à sua rotina." />

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <TimeField id="workdayStart" label="Início do dia" value={data.workdayStart ?? ''} onChange={(v) => update({ workdayStart: v })} />
        <TimeField id="workdayEnd" label="Encerramento" value={data.workdayEnd ?? ''} onChange={(v) => update({ workdayEnd: v })} />
      </div>

      <TimeField
        id="dailyReviewTime"
        label="Quando revisar as prioridades do dia"
        value={data.dailyReviewTime ?? ''}
        onChange={(v) => update({ dailyReviewTime: v })}
      />

      <ToggleRow
        label="Destacar conteúdos atrasados"
        description="Mostrar um realce visual para o que passou do prazo."
        checked={data.showOverdueHighlights ?? true}
        onToggle={() => update({ showOverdueHighlights: !(data.showOverdueHighlights ?? true) })}
      />

      <div className="flex flex-col gap-2.5">
        <p className="text-[13.5px] font-semibold text-[#f5f5f7]">O que mostrar na lista de tarefas?</p>
        <div className="grid grid-cols-2 gap-2">
          <SelectableCard
            compact
            selected={visibility === 'today'}
            onSelect={() => update({ taskVisibility: 'today' as TaskVisibility })}
            title="Apenas hoje"
          />
          <SelectableCard
            compact
            selected={visibility === 'upcoming'}
            onSelect={() => update({ taskVisibility: 'upcoming' as TaskVisibility })}
            title="Hoje e próximas"
          />
        </div>
      </div>
    </div>
  )
}
