'use client'

import { Check } from 'lucide-react'
import { GOAL_OPTIONS, MAX_GOALS } from '@/lib/onboarding-options'
import { StepHeader } from '../primitives'
import type { StepProps } from '../step-props'
import { cn } from '@/lib/utils'

export function GoalsStep({ data, update, showErrors }: StepProps) {
  const goals = data.goals ?? []
  const error = showErrors && goals.length === 0 ? 'Escolha ao menos um objetivo.' : undefined

  function toggle(id: string) {
    const current = data.goals ?? []
    if (current.includes(id)) {
      const next = current.filter((g) => g !== id)
      update({ goals: next, primaryGoal: next[0] ?? '' })
      return
    }
    if (current.length >= MAX_GOALS) return
    const next = [...current, id]
    update({ goals: next, primaryGoal: next[0] })
  }

  return (
    <div className="flex flex-col gap-6">
      <StepHeader
        title="O que você mais quer organizar na Panza?"
        description="Escolha até três. A primeira define onde você começa ao entrar."
      />

      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {GOAL_OPTIONS.map((goal) => {
          const index = goals.indexOf(goal.id)
          const selected = index !== -1
          const isPrimary = index === 0
          const atLimit = goals.length >= MAX_GOALS && !selected
          return (
            <button
              key={goal.id}
              type="button"
              role="checkbox"
              aria-checked={selected}
              disabled={atLimit}
              onClick={() => toggle(goal.id)}
              className={cn(
                'group flex items-center gap-2.5 rounded-md border px-3.5 py-3 text-left transition-all duration-150',
                selected
                  ? 'border-[rgba(255,255,255,0.55)] bg-[rgba(255,255,255,0.06)]'
                  : 'border-[rgba(255,255,255,0.1)] bg-[#101010] hover:border-[rgba(255,255,255,0.22)] hover:bg-[#161616]',
                atLimit ? 'cursor-not-allowed opacity-40' : '',
              )}
            >
              <span
                className={cn(
                  'flex size-[18px] shrink-0 items-center justify-center rounded border transition-all',
                  selected ? 'border-[#f5f5f7] bg-[#f5f5f7]' : 'border-[rgba(255,255,255,0.25)]',
                )}
              >
                {selected ? <Check className="size-3 text-[#050505]" strokeWidth={3} /> : null}
              </span>
              <span className="text-[13.5px] font-medium text-[#f5f5f7]">{goal.label}</span>
              {isPrimary ? (
                <span className="ml-auto rounded-full border border-[rgba(255,255,255,0.2)] px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-[#a1a1a6]">
                  Principal
                </span>
              ) : null}
            </button>
          )
        })}
      </div>

      {error ? <p className="text-[12px] text-[#fb2c36]">{error}</p> : null}
      <p className="text-[12px] text-[#6e6e73]">{goals.length} de {MAX_GOALS} selecionados</p>
    </div>
  )
}
