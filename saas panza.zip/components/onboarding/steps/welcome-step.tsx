'use client'

import { Clock } from 'lucide-react'

export function WelcomeStep() {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-3">
        <h1 className="text-[32px] sm:text-[40px] font-extrabold text-[#f5f5f7] tracking-tight leading-[1.05] text-balance">
          Vamos preparar a Panza para o seu jeito de trabalhar.
        </h1>
        <p className="text-[15px] sm:text-[16px] text-[#a1a1a6] leading-relaxed text-pretty max-w-[440px]">
          Responda algumas perguntas para personalizarmos sua fila de conteúdo, tarefas, agenda e
          entregas.
        </p>
      </div>
      <div className="flex items-center gap-2 text-[12.5px] font-medium text-[#6e6e73]">
        <Clock className="size-3.5" />
        Leva menos de 2 minutos.
      </div>
    </div>
  )
}
