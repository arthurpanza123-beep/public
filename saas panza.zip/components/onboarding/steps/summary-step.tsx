'use client'

import { DEFAULT_CONTENT_TYPES, DEFAULT_WORKFLOW_STAGES, OPERATION_OPTIONS, labelForGoal } from '@/lib/onboarding-options'
import { DEFAULT_RECURRING_TASKS } from '@/lib/onboarding-options'
import type { StepProps } from '../step-props'

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-4 py-2.5">
      <span className="text-[12.5px] font-medium text-[#6e6e73]">{label}</span>
      <span className="text-[13px] font-semibold text-[#f5f5f7] text-right">{value || '—'}</span>
    </div>
  )
}

export function SummaryStep({ data, customContentTypes }: StepProps) {
  const operationLabel = OPERATION_OPTIONS.find((o) => o.id === data.operationType)?.label ?? '—'

  const contentLookup = [...DEFAULT_CONTENT_TYPES, ...customContentTypes]
  const contentLabels = (data.contentTypeIds ?? [])
    .map((id) => contentLookup.find((c) => c.id === id)?.label)
    .filter(Boolean)
    .join(', ')

  const stages = (data.workflowStages ?? DEFAULT_WORKFLOW_STAGES).filter((s) => s.enabled).map((s) => s.label).join(' → ')

  const taskLabels = (data.recurringTaskIds ?? [])
    .map((id) => DEFAULT_RECURRING_TASKS.find((t) => t.id === id)?.label)
    .filter(Boolean)
    .join(', ')

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-2.5">
        <h1 className="text-[28px] sm:text-[34px] font-extrabold text-[#f5f5f7] tracking-tight leading-[1.1] text-balance">
          Tudo pronto para começar.
        </h1>
        <p className="text-[14.5px] text-[#a1a1a6] leading-relaxed text-pretty">
          A Panza foi preparada para o seu fluxo de produção.
        </p>
      </div>

      <div className="divide-y divide-[rgba(255,255,255,0.07)] rounded-md border border-[rgba(255,255,255,0.1)] bg-[#101010] px-4 py-1">
        <SummaryRow label="Nome" value={data.professionalName?.trim() || data.displayName || ''} />
        <SummaryRow label="Função" value={data.role ?? ''} />
        <SummaryRow label="Operação" value={operationLabel} />
        <SummaryRow label="Objetivo principal" value={data.primaryGoal ? labelForGoal(data.primaryGoal) : ''} />
        <SummaryRow label="Produção semanal" value={data.weeklyVolume ?? ''} />
        <SummaryRow label="Tipos de conteúdo" value={contentLabels} />
        <SummaryRow label="Fluxo" value={stages} />
        <SummaryRow label="Tarefas recorrentes" value={taskLabels} />
      </div>
    </div>
  )
}
