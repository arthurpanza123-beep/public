'use client'

import { useState } from 'react'
import { Plus } from 'lucide-react'
import { DEFAULT_CONTENT_TYPES } from '@/lib/onboarding-options'
import type { ContentType } from '@/lib/onboarding-types'
import { MultiSelectCard, StepHeader } from '../primitives'
import type { StepProps } from '../step-props'

function slugify(label: string): string {
  return (
    'custom_' +
    label
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '')
  )
}

export function ContentTypesStep({ data, update, customContentTypes, setCustomContentTypes, showErrors }: StepProps) {
  const [input, setInput] = useState('')
  const selected = data.contentTypeIds ?? []
  const all: ContentType[] = [...DEFAULT_CONTENT_TYPES, ...customContentTypes]
  const error = showErrors && selected.length === 0 ? 'Escolha ao menos um tipo de conteúdo.' : undefined

  function toggle(id: string) {
    const next = selected.includes(id) ? selected.filter((s) => s !== id) : [...selected, id]
    update({ contentTypeIds: next })
  }

  function addCustom() {
    const label = input.trim()
    if (!label) return
    const id = slugify(label)
    if (!all.some((t) => t.id === id)) {
      setCustomContentTypes([...customContentTypes, { id, label, custom: true }])
    }
    if (!selected.includes(id)) update({ contentTypeIds: [...selected, id] })
    setInput('')
  }

  return (
    <div className="flex flex-col gap-6">
      <StepHeader
        title="Que tipo de conteúdo você produz?"
        description="Esses tipos vão aparecer ao criar conteúdos e projetos."
      />

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {all.map((t) => (
          <MultiSelectCard key={t.id} label={t.label} selected={selected.includes(t.id)} onToggle={() => toggle(t.id)} />
        ))}
      </div>

      <div className="flex items-center gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault()
              addCustom()
            }
          }}
          placeholder="Adicionar outro tipo"
          aria-label="Adicionar tipo de conteúdo personalizado"
          className="h-10 flex-1 rounded-md border border-[rgba(255,255,255,0.12)] bg-[#101010] px-3.5 text-[13.5px] text-[#f5f5f7] placeholder:text-[#5a5a63] outline-none focus:border-[rgba(255,255,255,0.45)]"
        />
        <button
          type="button"
          onClick={addCustom}
          disabled={!input.trim()}
          className="flex h-10 items-center gap-1.5 rounded-md border border-[rgba(255,255,255,0.12)] px-3.5 text-[13px] font-semibold text-[#f5f5f7] transition-colors hover:border-[rgba(255,255,255,0.3)] disabled:opacity-40"
        >
          <Plus className="size-4" />
          Adicionar
        </button>
      </div>

      {error ? <p className="text-[12px] text-[#fb2c36]">{error}</p> : null}
    </div>
  )
}
