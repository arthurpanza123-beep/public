'use client'

import { User, Users, UsersRound, Building2 } from 'lucide-react'
import { OPERATION_OPTIONS } from '@/lib/onboarding-options'
import type { OperationType } from '@/lib/onboarding-types'
import { SelectableCard, StepHeader, TextField } from '../primitives'
import type { StepProps } from '../step-props'

const ICONS = {
  solo: User,
  partners: Users,
  small_team: UsersRound,
  studio: Building2,
} as const

export function OperationStep({ data, update }: StepProps) {
  const isTeam = data.operationType === 'small_team' || data.operationType === 'studio'

  return (
    <div className="flex flex-col gap-6">
      <StepHeader title="Como é a sua operação?" description="Isso ajuda a Panza a se ajustar ao tamanho do seu trabalho." />

      <div className="flex flex-col gap-2.5">
        {OPERATION_OPTIONS.map((op) => (
          <SelectableCard
            key={op.id}
            icon={ICONS[op.id]}
            selected={data.operationType === op.id}
            onSelect={() => update({ operationType: op.id as OperationType })}
            title={op.label}
            description={op.desc}
          />
        ))}
      </div>

      {isTeam ? (
        <div className="rounded-md border border-[rgba(255,255,255,0.1)] bg-[#0c0c0c] p-4">
          <p className="mb-3 text-[12.5px] font-semibold text-[#a1a1a6]">
            Sobre a equipe <span className="font-normal text-[#6e6e73]">(opcional)</span>
          </p>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <TextField
              id="teamSize"
              label="Quantas pessoas"
              value={data.teamSize ? String(data.teamSize) : ''}
              onChange={(v) => {
                const n = Number.parseInt(v.replace(/\D/g, ''), 10)
                update({ teamSize: Number.isNaN(n) ? undefined : n })
              }}
              placeholder="Ex.: 4"
              optional
            />
            <TextField
              id="teamRoles"
              label="Funções principais"
              value={(data.teamRoles ?? []).join(', ')}
              onChange={(v) => update({ teamRoles: v.split(',').map((s) => s.trim()).filter(Boolean) })}
              placeholder="Ex.: edição, captação"
              optional
            />
          </div>
        </div>
      ) : null}
    </div>
  )
}
