'use client'

import { DEFAULT_RECURRING_TASKS } from '@/lib/onboarding-options'
import type { TaskRecurrence } from '@/lib/onboarding-types'
import { MultiSelectCard, SelectableCard, StepHeader } from '../primitives'
import type { StepProps } from '../step-props'

const RECURRENCE_OPTIONS: { id: TaskRecurrence; label: string }[] = [
  { id: 'daily', label: 'Todos os dias' },
  { id: 'workdays', label: 'Dias úteis' },
  { id: 'specific', label: 'Dias específicos' },
  { id: 'none', label: 'Sem recorrência' },
]

export function RoutineStep({ data, update }: StepProps) {
  const selected = data.recurringTaskIds ?? []
  const recurrence = data.taskRecurrence ?? 'workdays'

  function toggle(id: string) {
    const next = selected.includes(id) ? selected.filter((s) => s !== id) : [...selected, id]
    update({ recurringTaskIds: next })
  }

  return (
    <div className="flex flex-col gap-6">
      <StepHeader
        title="Quais tarefas fazem parte da sua rotina?"
        description="Vamos montar seu checklist padrão com o que você escolher."
      />

      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {DEFAULT_RECURRING_TASKS.map((t) => (
          <MultiSelectCard key={t.id} label={t.label} selected={selected.includes(t.id)} onToggle={() => toggle(t.id)} />
        ))}
      </div>

      <div className="flex flex-col gap-3 pt-1">
        <p className="text-[13.5px] font-semibold text-[#f5f5f7]">Com que frequência essas tarefas se repetem?</p>
        <div className="grid grid-cols-2 gap-2">
          {RECURRENCE_OPTIONS.map((r) => (
            <SelectableCard
              key={r.id}
              compact
              selected={recurrence === r.id}
              onSelect={() => update({ taskRecurrence: r.id })}
              title={r.label}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
