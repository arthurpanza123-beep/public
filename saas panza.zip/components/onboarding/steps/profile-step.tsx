'use client'

import { ROLE_OPTIONS } from '@/lib/onboarding-options'
import { StepHeader, TextField } from '../primitives'
import type { StepProps } from '../step-props'
import { cn } from '@/lib/utils'

export function ProfileStep({ data, update, goNext, showErrors }: StepProps) {
  const nameError = showErrors && !data.displayName?.trim() ? 'Informe como devemos chamar você.' : undefined

  return (
    <div className="flex flex-col gap-6">
      <StepHeader title="Primeiro, como devemos chamar você?" />

      <div className="flex flex-col gap-4">
        <TextField
          id="displayName"
          label="Seu nome"
          value={data.displayName ?? ''}
          onChange={(v) => update({ displayName: v })}
          placeholder="Ex.: Alessandro"
          error={nameError}
          autoFocus
          onEnter={goNext}
        />
        <TextField
          id="professionalName"
          label="Nome profissional ou apelido"
          value={data.professionalName ?? ''}
          onChange={(v) => update({ professionalName: v })}
          placeholder="Como aparece para clientes"
          optional
          onEnter={goNext}
        />
      </div>

      <fieldset className="flex flex-col gap-2.5">
        <legend className="text-[12.5px] font-semibold text-[#a1a1a6] mb-2">Qual é a sua função?</legend>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-2">
          {ROLE_OPTIONS.map((role) => {
            const selected = data.role === role
            return (
              <button
                key={role}
                type="button"
                aria-pressed={selected}
                onClick={() => update({ role })}
                className={cn(
                  'rounded-md border px-3.5 py-2.5 text-left text-[13.5px] font-medium transition-all duration-150',
                  selected
                    ? 'border-[rgba(255,255,255,0.55)] bg-[rgba(255,255,255,0.06)] text-[#f5f5f7]'
                    : 'border-[rgba(255,255,255,0.1)] bg-[#101010] text-[#a1a1a6] hover:border-[rgba(255,255,255,0.22)] hover:text-[#f5f5f7]',
                )}
              >
                {role}
              </button>
            )
          })}
        </div>
      </fieldset>
    </div>
  )
}
