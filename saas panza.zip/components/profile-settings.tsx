'use client'

import Link from 'next/link'
import { useProfile, useDisplayName, initialsFromName } from '@/lib/profile-store'
import { labelForGoal } from '@/lib/onboarding-options'
import { Sparkles, ChevronRight } from 'lucide-react'

export function ProfileSettings() {
  const profile = useProfile()
  const displayName = useDisplayName()
  const initials = initialsFromName(displayName)
  const roleLabel = profile?.role?.trim() || 'Creator Pro'
  const personalized = Boolean(profile?.onboardingCompleted)

  return (
    <>
      {/* Perfil */}
      <section className="glass-card rounded-xl overflow-hidden">
        <div className="px-5 py-3" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
          <p className="text-[12px] font-bold uppercase tracking-[0.12em] text-white/30">Perfil</p>
        </div>
        <div className="p-5 flex items-center gap-4">
          <div
            className="size-14 rounded-full flex items-center justify-center text-[17px] font-extrabold flex-shrink-0"
            style={{ background: '#f4f4f6', color: '#0a0a0c' }}
          >
            {initials}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[14.5px] font-bold text-white truncate">{displayName}</p>
            <p className="text-[12px] text-white/40 truncate">{roleLabel}</p>
          </div>
          <Link
            href="/onboarding"
            className="glass-soft h-9 px-4 rounded-lg text-[12.5px] font-medium text-white/60 transition-colors hover:text-white flex items-center"
          >
            Editar
          </Link>
        </div>
      </section>

      {/* Personalização */}
      <section className="glass-card rounded-xl overflow-hidden">
        <div className="px-5 py-3 flex items-center justify-between" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
          <p className="text-[12px] font-bold uppercase tracking-[0.12em] text-white/30">
            Perfil e personalização
          </p>
          {personalized ? (
            <span
              className="text-[10.5px] font-bold px-2.5 py-1 rounded"
              style={{ background: 'rgba(255,255,255,0.14)', color: '#f4f4f6' }}
            >
              Configurado
            </span>
          ) : null}
        </div>

        {personalized ? (
          <div className="p-5 flex flex-col gap-4">
            <div className="grid grid-cols-2 gap-x-6 gap-y-4">
              <Field label="Objetivo principal" value={profile?.primaryGoal ? labelForGoal(profile.primaryGoal) : '—'} />
              <Field label="Operação" value={operationLabel(profile?.operationType)} />
              <Field label="Volume semanal" value={profile?.weeklyVolume || '—'} />
              <Field
                label="Tipos de conteúdo"
                value={profile?.contentTypeIds?.length ? `${profile.contentTypeIds.length} selecionados` : '—'}
              />
              <Field
                label="Etapas do fluxo"
                value={
                  profile?.workflowStages?.filter((s) => s.enabled).length
                    ? `${profile.workflowStages.filter((s) => s.enabled).length} ativas`
                    : '—'
                }
              />
              <Field
                label="Tarefas recorrentes"
                value={profile?.recurringTaskIds?.length ? `${profile.recurringTaskIds.length} ativas` : '—'}
              />
            </div>
            <Link
              href="/onboarding"
              className="glass-soft flex items-center justify-between rounded-lg px-4 py-3 transition-colors hover:bg-white/[0.06]"
            >
              <span className="flex items-center gap-2.5">
                <Sparkles className="size-4 text-white/50" />
                <span className="text-[13px] font-medium text-white">Refazer a personalização</span>
              </span>
              <ChevronRight className="size-4 text-white/30" />
            </Link>
          </div>
        ) : (
          <div className="p-5 flex items-center gap-4">
            <div className="glass-soft size-9 rounded-lg flex items-center justify-center flex-shrink-0">
              <Sparkles className="size-4 text-white/50" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[13.5px] font-semibold text-white">Personalize sua Panza</p>
              <p className="text-[11.5px] text-white/35">
                Responda algumas perguntas para adaptar o painel à sua rotina
              </p>
            </div>
            <Link
              href="/onboarding"
              className="btn-accent text-[12.5px] font-bold px-3 py-1.5 rounded-lg"
            >
              Começar
            </Link>
          </div>
        )}
      </section>
    </>
  )
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-1 min-w-0">
      <span className="text-[11px] uppercase tracking-[0.1em] text-white/30">{label}</span>
      <span className="text-[13px] font-medium text-white truncate">{value}</span>
    </div>
  )
}

function operationLabel(op?: string): string {
  switch (op) {
    case 'solo':
      return 'Trabalho sozinho'
    case 'partners':
      return 'Com parceiros'
    case 'small_team':
      return 'Pequena equipe'
    case 'studio':
      return 'Produtora'
    default:
      return '—'
  }
}
