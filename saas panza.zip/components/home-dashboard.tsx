'use client'

import { useState } from 'react'
import {
  ArrowUp, Bell, Upload, PenLine, Scissors,
  ChevronRight, TrendingUp, Flame, CirclePlay,
} from 'lucide-react'
import { videos, opportunities } from '@/lib/mock-data'
import type { Opportunity } from '@/lib/mock-data'
import { VideoCard } from './video-card'
import { OpportunityModal, WhatsAppModal } from './modals'
import Link from 'next/link'
import { useProfile, useDisplayName } from '@/lib/profile-store'
import { labelForGoal } from '@/lib/onboarding-options'

const hour = new Date().getHours()
const greeting = hour < 12 ? 'Bom dia' : hour < 18 ? 'Boa tarde' : 'Boa noite'

const GOAL_FOCUS: Record<string, string> = {
  produce_today: 'Foco de hoje: decidir o que produzir',
  edit_queue: 'Foco de hoje: avançar a fila de edição',
  never_miss_publish: 'Foco de hoje: não esquecer nenhuma publicação',
  approvals: 'Foco de hoje: destravar as aprovações',
  deliveries: 'Foco de hoje: organizar as entregas',
  clients: 'Foco de hoje: cuidar dos clientes',
  projects: 'Foco de hoje: acompanhar os projetos',
  daily_tasks: 'Foco de hoje: organizar suas tarefas',
  agenda: 'Foco de hoje: ajustar sua agenda',
}

const quickActions = [
  { icon: Upload,    label: 'Enviar vídeo bruto',  desc: 'Mande seu vídeo e a IA edita, corta e posta',  href: '/biblioteca', accent: true  },
  { icon: PenLine,   label: 'Criar roteiro',        desc: 'Converse com a IA e monte seu próximo vídeo',  href: '/estudio',    accent: false },
  { icon: Scissors,  label: 'Gerar cortes',         desc: 'Transforme um vídeo longo em Shorts',          href: '/estudio',    accent: false },
  { icon: TrendingUp,label: 'Ver oportunidades',    desc: 'Temas em alta no seu nicho agora',             href: '/oportunidades', accent: false },
]

export function HomeDashboard() {
  const [prompt, setPrompt] = useState('')
  const [selectedOp, setSelectedOp] = useState<Opportunity | null>(null)
  const [whatsappOpen, setWhatsappOpen] = useState(false)
  const profile = useProfile()
  const displayName = useDisplayName()
  const firstName = displayName.split(' ')[0]
  const focusLine =
    profile?.primaryGoal && GOAL_FOCUS[profile.primaryGoal]
      ? GOAL_FOCUS[profile.primaryGoal]
      : profile?.primaryGoal
        ? `Foco de hoje: ${labelForGoal(profile.primaryGoal)}`
        : null

  return (
    <>
    <div className="px-8 py-7 max-w-[1240px] mx-auto flex flex-col gap-8">

      {/* Saudacao + alerta de oportunidade */}
      <section className="afu flex flex-col gap-4">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-[12px] font-bold uppercase tracking-[0.18em] text-white/30 mb-1">
              {greeting}{firstName ? `, ${firstName}` : ''}
            </p>
            <h1 className="text-[30px] font-extrabold text-white tracking-tight leading-none">
              {displayName}
            </h1>
            {focusLine ? (
              <p className="text-[12.5px] text-white/45 mt-2">{focusLine}</p>
            ) : null}
          </div>
          {/* Alerta ativo */}
          <div
            className="glass-card glass-card-hover flex items-center gap-3 px-4 py-2.5 rounded-lg cursor-pointer shrink-0"
            onClick={() => setSelectedOp(opportunities[0])}
          >
            <div className="relative">
              <Bell className="size-4 text-white/80" />
              <span className="absolute -top-0.5 -right-0.5 size-2 rounded-full bg-[#f4f4f6]" />
            </div>
            <div>
              <p className="text-[12px] font-bold text-white">Oportunidade detectada</p>
              <p className="text-[11px] text-white/45">IA encontrou 3 temas em alta no seu nicho</p>
            </div>
            <ChevronRight className="size-4 text-white/30" />
          </div>
        </div>

        {/* Acoes rapidas */}
        <div className="grid grid-cols-4 gap-3">
          {quickActions.map((a) => {
            const Icon = a.icon
            return (
              <Link
                key={a.label}
                href={a.href}
                className={`group flex flex-col gap-3 p-4 rounded-xl transition-all duration-200 hover:scale-[1.01] ${a.accent ? 'btn-accent' : 'glass-card glass-card-hover'}`}
              >
                <div
                  className="size-9 rounded-lg flex items-center justify-center"
                  style={a.accent
                    ? { background: 'rgba(10,10,12,0.10)' }
                    : { background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.10)' }
                  }
                >
                  <Icon className="size-4" style={{ color: a.accent ? '#0a0a0c' : '#f4f4f6' }} />
                </div>
                <div>
                  <p className={`text-[13px] font-bold leading-tight ${a.accent ? 'text-[#0a0a0c]' : 'text-white'}`}>
                    {a.label}
                  </p>
                  <p className={`text-[11px] mt-0.5 leading-snug ${a.accent ? 'text-[#0a0a0c]/70' : 'text-white/40'}`}>
                    {a.desc}
                  </p>
                </div>
              </Link>
            )
          })}
        </div>
      </section>

      {/* Chat IA rapido */}
      <section className="afu-1">
        <div className="glass-card rounded-xl p-1.5">
          <div className="flex items-end gap-2 px-3 pt-3 pb-2">
            <div className="size-6 rounded flex items-center justify-center flex-shrink-0 mb-0.5 bg-[#f4f4f6]">
              <img src="/panza-p.png" alt="" className="size-4 object-contain invert" />
            </div>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={1}
              placeholder="Qual é o tema do seu próximo vídeo? A IA monta o roteiro completo..."
              className="flex-1 bg-transparent resize-none text-[13.5px] text-white placeholder:text-white/30 outline-none leading-relaxed"
            />
            <Link
              href={`/estudio${prompt ? `?q=${encodeURIComponent(prompt)}` : ''}`}
              className="size-8 rounded-lg flex items-center justify-center flex-shrink-0 transition-colors"
              style={{ background: prompt ? '#f4f4f6' : 'rgba(255,255,255,0.08)' }}
            >
              <ArrowUp className="size-4" strokeWidth={2.5} style={{ color: prompt ? '#0a0a0c' : '#f4f4f6' }} />
            </Link>
          </div>
          <div className="flex items-center gap-2 px-3 pb-2.5 flex-wrap">
            {opportunities.slice(0, 3).map((o) => (
              <button
                key={o.id}
                onClick={() => setPrompt(o.title)}
                className="flex items-center gap-1.5 text-[11.5px] text-white/40 hover:text-white px-3 py-1.5 rounded-full transition-colors"
                style={{ border: '1px solid #1f1f24' }}
              >
                <Flame className="size-3 text-white/25" />
                {o.title.split(':')[0]}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Continuar criando */}
      <section className="afu-2">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-[17px] font-bold text-white tracking-tight">Continue criando</h2>
            <p className="text-[12px] text-white/35 mt-0.5">Seus projetos em andamento</p>
          </div>
          <Link href="/biblioteca" className="flex items-center gap-1 text-[12px] font-medium text-white/40 hover:text-white transition-colors">
            Ver todos
            <ChevronRight className="size-3.5" />
          </Link>
        </div>
        <div className="grid grid-cols-3 gap-5">
          {videos.filter(v => v.status !== 'publicado').slice(0, 3).map((v) => (
            <VideoCard key={v.id} video={v} />
          ))}
        </div>
      </section>

      {/* Publicados */}
      <section className="afu-3 pb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-[17px] font-bold text-white tracking-tight">Publicados recentemente</h2>
            <p className="text-[12px] text-white/35 mt-0.5">Conteudo que ja está no ar</p>
          </div>
          <Link href="/biblioteca" className="flex items-center gap-1 text-[12px] font-medium text-white/40 hover:text-white transition-colors">
            Ver biblioteca
            <ChevronRight className="size-3.5" />
          </Link>
        </div>
        <div className="grid grid-cols-3 gap-5">
          {videos.filter(v => v.status === 'publicado').slice(0, 3).map((v) => (
            <VideoCard key={v.id} video={v} />
          ))}
        </div>
      </section>

    </div>

    {/* Modais */}
    {selectedOp && <OpportunityModal op={selectedOp} onClose={() => setSelectedOp(null)} />}
    {whatsappOpen && <WhatsAppModal onClose={() => setWhatsappOpen(false)} />}
    </>
  )
}
