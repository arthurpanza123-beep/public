'use client'

import { useState } from 'react'
import { videos } from '@/lib/mock-data'
import { VideoCard } from './video-card'
import { Search, LayoutGrid, List, Upload, CloudUpload } from 'lucide-react'

const filters = ['Todos', 'Publicados', 'Prontos', 'Editando', 'Rascunhos']

export function LibraryView() {
  const [active, setActive] = useState('Todos')
  const [query, setQuery] = useState('')
  const [dragging, setDragging] = useState(false)

  const filtered = videos.filter((v) => {
    const matchQuery = v.title.toLowerCase().includes(query.toLowerCase())
    const matchFilter =
      active === 'Todos' ||
      (active === 'Publicados' && v.status === 'publicado') ||
      (active === 'Prontos' && v.status === 'pronto') ||
      (active === 'Editando' && v.status === 'editando') ||
      (active === 'Rascunhos' && v.status === 'rascunho')
    return matchQuery && matchFilter
  })

  return (
    <div className="px-8 py-7 max-w-[1240px] mx-auto flex flex-col gap-6">
      {/* Header */}
      <div className="flex items-end justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-[26px] font-extrabold text-white tracking-tight">Meus Vídeos</h1>
          <p className="text-[13.5px] text-white/40 mt-1">
            {videos.length} vídeos · Envie o bruto e a IA edita, corta e posta
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="glass-card flex items-center gap-2 h-9 px-3 rounded-lg w-52">
            <Search className="size-3.5 text-white/30 flex-shrink-0" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar vídeos..."
              className="bg-transparent text-[13px] text-white placeholder:text-white/30 outline-none flex-1 min-w-0"
            />
          </div>
          <button className="btn-accent flex items-center gap-1.5 h-9 px-4 rounded-lg text-[12.5px] font-bold">
            <Upload className="size-3.5" strokeWidth={2.5} />
            Enviar vídeo
          </button>
        </div>
      </div>

      {/* Upload drop zone */}
      <div
        className="flex flex-col items-center justify-center gap-3 rounded-xl py-8 border-dashed cursor-pointer transition-all duration-200"
        style={{
          border: dragging ? '2px dashed rgba(255,255,255,0.45)' : '2px dashed #26262c',
          background: dragging ? 'rgba(255,255,255,0.04)' : 'transparent',
        }}
        onDragOver={(e) => { e.preventDefault(); setDragging(true) }}
        onDragLeave={() => setDragging(false)}
        onDrop={() => setDragging(false)}
      >
        <div
          className="size-12 rounded-xl flex items-center justify-center"
          style={{ background: dragging ? 'rgba(255,255,255,0.12)' : 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
        >
          <CloudUpload className="size-6" style={{ color: dragging ? '#f4f4f6' : 'rgba(255,255,255,0.3)' }} />
        </div>
        <div className="text-center">
          <p className="text-[14px] font-semibold text-white">Arraste seu vídeo bruto aqui</p>
          <p className="text-[12px] text-white/35 mt-0.5">
            A IA faz os cortes, adiciona legendas, gera thumbnail e posta no YouTube automaticamente
          </p>
        </div>
        <label className="glass-soft flex items-center gap-1.5 h-8 px-4 rounded-lg text-[12px] font-semibold cursor-pointer transition-colors text-white/60 hover:text-white"
        >
          <Upload className="size-3.5" />
          Selecionar arquivo
          <input type="file" accept="video/*" className="hidden" />
        </label>
      </div>

      {/* Filters */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-1.5 flex-wrap">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setActive(f)}
              className="h-8 px-3.5 rounded-full text-[12.5px] font-semibold transition-all duration-150"
              style={active === f
                ? { background: '#f4f4f6', color: '#0a0a0c' }
                : { background: 'rgba(255,255,255,0.04)', color: 'rgba(255,255,255,0.45)', border: '1px solid rgba(255,255,255,0.08)' }}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="glass-soft flex items-center gap-1 p-1 rounded-lg">
          <button className="size-7 rounded flex items-center justify-center text-white" style={{ background: 'rgba(255,255,255,0.08)' }}>
            <LayoutGrid className="size-3.5" />
          </button>
          <button className="size-7 rounded flex items-center justify-center text-white/30 hover:text-white transition-colors">
            <List className="size-3.5" />
          </button>
        </div>
      </div>

      {/* Grid */}
      {filtered.length > 0 ? (
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-5 pb-8">
          {filtered.map((v) => (
            <VideoCard key={v.id} video={v} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <p className="text-[15px] font-semibold text-white/60">Nenhum vídeo encontrado</p>
          <p className="text-[13px] text-white/30 mt-1">Tente outro filtro ou envie seu primeiro vídeo.</p>
        </div>
      )}
    </div>
  )
}
