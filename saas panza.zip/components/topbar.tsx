'use client'

import { useState, useRef, useEffect } from 'react'
import { usePathname } from 'next/navigation'
import { Search, Bell, Plus } from 'lucide-react'
import { useDisplayName, initialsFromName } from '@/lib/profile-store'

const pageTitles: Record<string, string> = {
  '/':              'Início',
  '/estudio':       'Estúdio IA',
  '/biblioteca':    'Meus Vídeos',
  '/calendario':    'Calendário',
  '/oportunidades': 'Oportunidades',
  '/configuracoes': 'Configurações',
}

export function Topbar() {
  const pathname = usePathname()
  const title = pageTitles[pathname] ?? 'Panza Creator'
  const displayName = useDisplayName()
  const avatarInitial = initialsFromName(displayName).charAt(0)
  const [notifOpen, setNotifOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    function h(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setNotifOpen(false)
    }
    document.addEventListener('mousedown', h)
    return () => document.removeEventListener('mousedown', h)
  }, [])

  return (
    <header
      className="fixed top-0 left-[216px] right-0 h-[52px] flex items-center px-6 z-30 gap-4"
      style={{ background: 'rgba(9,9,11,0.6)', backdropFilter: 'blur(24px) saturate(150%)', WebkitBackdropFilter: 'blur(24px) saturate(150%)', borderBottom: '1px solid rgba(255,255,255,0.07)' }}
    >
      {/* Page title */}
      <span className="text-[14px] font-bold text-[#ededef] tracking-[-0.02em]">{title}</span>

      {/* Search */}
      <div
        className="flex items-center gap-2 px-3 h-[30px] w-56 cursor-text ml-4"
        style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid #1f1f24' }}
      >
        <Search size={12} className="text-[#3a3a42] flex-shrink-0" />
        <span className="text-[12px] text-[#3a3a42] flex-1 select-none">Buscar...</span>
        <kbd className="text-[10px] text-[#2a2a30] border border-[#2a2a30] px-1 rounded-sm">⌘K</kbd>
      </div>

      <div className="ml-auto flex items-center gap-2">
        {/* Bell */}
        <div className="relative" ref={ref}>
          <button
            onClick={() => setNotifOpen(v => !v)}
            className="relative w-8 h-8 flex items-center justify-center text-[#48484f] hover:text-[#ededef] hover:bg-[#131316] rounded-sm transition-colors"
          >
            <Bell size={15} strokeWidth={1.8} />
            <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-[#f4f4f6]" />
          </button>
          {notifOpen && (
            <div className="absolute right-0 top-[calc(100%+6px)] w-72 z-50 rounded-sm overflow-hidden shadow-2xl shadow-black/70" style={{ background: '#111113', border: '1px solid #1f1f24' }}>
              <div className="px-4 py-3 flex items-center justify-between" style={{ borderBottom: '1px solid #1f1f24' }}>
                <span className="text-[13px] font-bold text-[#ededef]">Notificacoes</span>
                <span className="text-[11px] text-[#f4f4f6] font-medium cursor-pointer">3 novas</span>
              </div>
              {[
                { t: 'Video aprovado', d: 'Roteiro do video #34 foi aprovado.', time: '2m' },
                { t: 'Publicacao agendada', d: 'Conteudo para amanha 10h confirmado.', time: '1h' },
                { t: 'Meta atingida', d: 'Voce chegou a 100k visualizacoes.', time: '3h' },
              ].map((n, i) => (
                <div key={i} className="px-4 py-3 flex gap-3 hover:bg-[#161618] cursor-pointer transition-colors" style={{ borderBottom: i < 2 ? '1px solid #1a1a1d' : 'none' }}>
                  <span className="w-1.5 h-1.5 rounded-full bg-white/60 flex-shrink-0 mt-1.5" />
                  <div>
                    <p className="text-[12px] font-semibold text-[#ededef]">{n.t}</p>
                    <p className="text-[11px] text-[#48484f] mt-0.5">{n.d}</p>
                    <p className="text-[10px] text-[#2a2a30] mt-1">{n.time} atras</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Avatar */}
        <div className="w-7 h-7 rounded-sm bg-[#f4f4f6] flex items-center justify-center text-[11px] font-bold text-[#0a0a0c] cursor-pointer">
          {avatarInitial}
        </div>

        {/* CTA */}
        <button className="btn-accent flex items-center gap-1.5 h-[30px] px-4 text-[11px] font-bold uppercase tracking-[0.1em] rounded-sm">
          <Plus size={12} />
          Novo
        </button>
      </div>
    </header>
  )
}
