'use client'

import { useState, useRef, useEffect } from 'react'
import {
  ArrowUp, Sparkles, PenLine, Scissors,
  ImageIcon, Download, RefreshCw, Copy,
  Tag, AlignLeft, ThumbsUp,
} from 'lucide-react'

type MsgRole = 'user' | 'ai'
type MsgContent = 'script' | 'thumbnail' | 'cuts' | 'description' | null

interface Msg {
  role: MsgRole
  text: string
  content?: MsgContent
}

const starters = [
  { icon: PenLine,    label: 'Criar roteiro completo',       q: 'Me ajuda a criar um roteiro completo para YouTube' },
  { icon: ImageIcon,  label: 'Gerar thumbnail',               q: 'Cria uma ideia de thumbnail para meu próximo vídeo' },
  { icon: Scissors,   label: 'Cortar para Shorts/Reels',      q: 'Como eu corto meu vídeo longo para Shorts de 60s?' },
  { icon: AlignLeft,  label: 'Escrever descrição + tags',     q: 'Escreve a descrição e as tags do meu vídeo' },
]

function aiReply(q: string): { text: string; content: MsgContent } {
  const lower = q.toLowerCase()
  if (lower.includes('thumb'))
    return { text: 'Aqui está uma sugestão de thumbnail de alto impacto. Use contraste forte, rosto expressivo e texto grande. Quer variações de cor ou composição?', content: 'thumbnail' }
  if (lower.includes('descriç') || lower.includes('tag'))
    return { text: 'Gerado! Descrição otimizada para SEO do YouTube com palavras-chave e as 10 melhores tags para esse tema:', content: 'description' }
  if (lower.includes('cort') || lower.includes('short') || lower.includes('reel'))
    return { text: 'Identifiquei os 3 melhores momentos para corte no seu vídeo. Cada um tem gancho forte nos primeiros 3 segundos — essencial para o algoritmo de Shorts.', content: 'cuts' }
  return { text: 'Roteiro pronto! Estruturei em Gancho (0-10s), Desenvolvimento e CTA. É especializado para YouTube — retenção alta na abertura é o que o algoritmo prioriza.', content: 'script' }
}

export function AIStudio({ initialQ }: { initialQ?: string }) {
  const [messages, setMessages] = useState<Msg[]>([])
  const [input, setInput] = useState('')
  const [typing, setTyping] = useState(false)
  const [dots, setDots] = useState(0)
  const endRef = useRef<HTMLDivElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const firedRef = useRef(false)

  // Typing dots animation
  useEffect(() => {
    if (!typing) return
    const iv = setInterval(() => setDots((d) => (d + 1) % 4), 400)
    return () => clearInterval(iv)
  }, [typing])

  // Auto-fire when arriving from ?q= param
  useEffect(() => {
    if (initialQ && !firedRef.current) {
      firedRef.current = true
      setTimeout(() => send(initialQ), 300)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, typing])

  function send(text: string) {
    if (!text.trim() || typing) return
    const { text: replyText, content } = aiReply(text)
    setMessages((m) => [...m, { role: 'user', text }])
    setInput('')
    setTyping(true)
    // auto-resize textarea back
    if (textareaRef.current) textareaRef.current.style.height = 'auto'
    setTimeout(() => {
      setTyping(false)
      setMessages((m) => [...m, { role: 'ai', text: replyText, content }])
    }, 1600)
  }

  function handleInput(e: React.ChangeEvent<HTMLTextAreaElement>) {
    setInput(e.target.value)
    e.target.style.height = 'auto'
    e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px'
  }

  const empty = messages.length === 0

  return (
    <div className="flex flex-col" style={{ height: 'calc(100vh - 52px)' }}>

      {/* Messages area */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-[760px] mx-auto px-6 py-8">
          {empty ? (
            <div className="flex flex-col items-center text-center pt-10 afu">
              <div
                className="size-14 rounded-2xl flex items-center justify-center mb-5"
                style={{ background: '#f4f4f6' }}
              >
                <img src="/panza-p.png" alt="" className="size-9 object-contain invert" />
              </div>
              <h1 className="text-[26px] font-extrabold text-white tracking-tight">Estúdio IA</h1>
              <p className="text-[14px] text-white/40 mt-2 max-w-sm leading-relaxed">
                Especializado em YouTube. Crie roteiros, thumbnails, descrições e cortes que aumentam sua audiência.
              </p>
              <div className="grid grid-cols-2 gap-3 mt-8 w-full max-w-xl">
                {starters.map((s) => {
                  const Icon = s.icon
                  return (
                    <button
                      key={s.label}
                      onClick={() => send(s.q)}
                      className="glass-card glass-card-hover flex items-start gap-3 p-4 rounded-xl text-left transition-all duration-150"
                    >
                      <div className="size-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.10)' }}>
                        <Icon className="size-3.5" style={{ color: '#f4f4f6' }} />
                      </div>
                      <span className="text-[13px] font-medium text-white leading-snug">{s.label}</span>
                    </button>
                  )
                })}
              </div>
            </div>
          ) : (
            <div className="flex flex-col gap-5">
              {messages.map((m, i) => (
                <ChatMessage key={i} msg={m} />
              ))}
              {typing && (
                <div className="flex items-start gap-3">
                  <div className="size-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: '#f4f4f6' }}>
                    <Sparkles className="size-3.5" style={{ color: '#0a0a0c' }} />
                  </div>
                  <div
                    className="flex items-center gap-1 px-4 py-3 rounded-2xl rounded-tl-sm"
                    style={{ background: '#111113', border: '1px solid #1f1f24' }}
                  >
                    {[0, 1, 2].map((i) => (
                      <span
                        key={i}
                        className="size-1.5 rounded-full bg-white/40"
                        style={{
                          animation: 'bounce 1.2s ease-in-out infinite',
                          animationDelay: `${i * 200}ms`,
                        }}
                      />
                    ))}
                  </div>
                </div>
              )}
              <div ref={endRef} />
            </div>
          )}
        </div>
      </div>

      {/* Composer */}
      <div className="flex-shrink-0 px-6 pb-5 pt-2">
        <div
          className="glass-card max-w-[760px] mx-auto rounded-xl overflow-hidden"
        >
          <div className="flex items-end gap-2 p-3">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={handleInput}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault()
                  send(input)
                }
              }}
              rows={1}
              placeholder="Qual o tema do vídeo? Descreva e a IA monta o roteiro..."
              className="flex-1 bg-transparent resize-none text-[14px] text-white placeholder:text-white/30 outline-none leading-relaxed px-1"
              style={{ minHeight: '24px', maxHeight: '120px' }}
            />
            <button
              onClick={() => send(input)}
              disabled={!input.trim() || typing}
              className="size-9 rounded-lg flex items-center justify-center flex-shrink-0 transition-all duration-150 disabled:opacity-35"
              style={{ background: '#f4f4f6' }}
            >
              <ArrowUp className="size-4" strokeWidth={2.5} style={{ color: '#0a0a0c' }} />
            </button>
          </div>
          <p className="text-[10.5px] text-white/20 text-center pb-2.5">
            Especializado em YouTube · Roteiros, thumbnails, descrição, tags e cortes
          </p>
        </div>
      </div>
    </div>
  )
}

function ChatMessage({ msg }: { msg: Msg }) {
  if (msg.role === 'user') {
    return (
      <div className="flex justify-end">
        <div
          className="max-w-[75%] px-4 py-2.5 rounded-2xl rounded-br-sm text-[13.5px] text-white leading-relaxed"
          style={{ background: '#1f1f24' }}
        >
          {msg.text}
        </div>
      </div>
    )
  }

  return (
    <div className="flex items-start gap-3">
      <div
        className="size-8 rounded-lg flex items-center justify-center flex-shrink-0"
        style={{ background: '#f4f4f6' }}
      >
        <Sparkles className="size-3.5" style={{ color: '#0a0a0c' }} />
      </div>
      <div className="flex-1 min-w-0 flex flex-col gap-3">
        <div
          className="px-4 py-3 rounded-2xl rounded-tl-sm text-[13.5px] text-white/80 leading-relaxed"
          style={{ background: '#111113', border: '1px solid #1f1f24' }}
        >
          {msg.text}
        </div>
        {msg.content === 'script'      && <ScriptCard />}
        {msg.content === 'thumbnail'   && <ThumbnailCard />}
        {msg.content === 'cuts'        && <CutsCard />}
        {msg.content === 'description' && <DescriptionCard />}
      </div>
    </div>
  )
}

function ScriptCard() {
  return (
    <div className="glass-card rounded-xl overflow-hidden max-w-lg">
      <div className="px-4 pt-3 pb-2" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
        <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-white/30">Roteiro · YouTube · 8-12 min</p>
      </div>
      <div className="p-4 flex flex-col gap-3 text-[13px] leading-relaxed">
        <div>
          <p className="text-[10.5px] font-bold text-white uppercase tracking-wide mb-1">Gancho (0-10s)</p>
          <p className="text-white/70">Você está cometendo 1 erro silencioso que impede seu canal de crescer. E eu precisei perder 6 meses para descobrir qual era.</p>
        </div>
        <div>
          <p className="text-[10.5px] font-bold text-white/40 uppercase tracking-wide mb-1">Desenvolvimento</p>
          <p className="text-white/50">Erro 1: títulos genéricos. Erro 2: thumbnails sem rosto. Erro 3: sem gancho nos primeiros 3 segundos...</p>
        </div>
        <div>
          <p className="text-[10.5px] font-bold text-white/40 uppercase tracking-wide mb-1">CTA (últimos 30s)</p>
          <p className="text-white/50">Comenta aqui qual erro você comete mais. Se esse vídeo te ajudou, deixa o like — ajuda muito o canal.</p>
        </div>
      </div>
      <div className="flex items-center gap-2 px-4 pb-4">
        <button className="btn-accent flex items-center gap-1.5 h-8 px-3 rounded-lg text-[12px] font-bold flex-1 justify-center">
          <Download className="size-3.5" /> Exportar roteiro
        </button>
        <button className="flex items-center gap-1.5 h-8 px-3 rounded-lg text-[12px] font-medium text-white/50" style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid #1f1f24' }}>
          <Copy className="size-3.5" /> Copiar
        </button>
        <button className="flex items-center gap-1.5 h-8 px-3 rounded-lg text-[12px] font-medium text-white/50" style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid #1f1f24' }}>
          <RefreshCw className="size-3.5" /> Refazer
        </button>
      </div>
    </div>
  )
}

function ThumbnailCard() {
  return (
    <div className="rounded-xl overflow-hidden max-w-md" style={{ border: '1px solid #1f1f24' }}>
      <div className="relative aspect-video">
        <img src="/thumbs/thumb-1.png" alt="Thumbnail gerada" className="w-full h-full object-cover" crossOrigin="anonymous" />
        <div className="absolute inset-0 flex items-end p-3" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.7) 0%, transparent 60%)' }}>
          <span className="text-[10px] font-bold text-white/60">Thumbnail gerada por IA</span>
        </div>
      </div>
      <div className="flex items-center gap-2 p-3" style={{ background: 'rgba(20,20,24,0.55)' }}>
        <button className="btn-accent flex items-center gap-1.5 h-8 px-3 rounded-lg text-[12px] font-bold flex-1 justify-center">
          <Download className="size-3.5" /> Baixar
        </button>
        <button className="flex items-center gap-1.5 h-8 px-3 rounded-lg text-[12px] text-white/50" style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid #1f1f24' }}>
          <RefreshCw className="size-3.5" /> Variações
        </button>
      </div>
    </div>
  )
}

function CutsCard() {
  const cuts = [
    { time: '02:14 — 03:05', label: 'Corte 1 · Gancho forte', score: 96 },
    { time: '07:42 — 08:30', label: 'Corte 2 · Momento viral', score: 88 },
    { time: '11:10 — 12:00', label: 'Corte 3 · CTA claro', score: 79 },
  ]
  return (
    <div className="glass-card rounded-xl overflow-hidden max-w-lg">
      <div className="px-4 pt-3 pb-2" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
        <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-white/30">3 cortes · Shorts & Reels</p>
      </div>
      <div className="p-3 flex flex-col gap-2">
        {cuts.map((c, i) => (
          <div key={i} className="flex items-center gap-3 p-3 rounded-lg" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
            <div className="size-7 rounded-md flex items-center justify-center flex-shrink-0 text-[11px] font-bold" style={{ background: '#f4f4f6', color: '#0a0a0c' }}>{i + 1}</div>
            <div className="flex-1 min-w-0">
              <p className="text-[12.5px] font-semibold text-white">{c.label}</p>
              <p className="text-[11px] text-white/35">{c.time}</p>
            </div>
            <div className="flex items-center gap-1.5">
              <ThumbsUp className="size-3 text-[#4ade80]" />
              <span className="text-[12px] font-bold text-[#4ade80]">{c.score}</span>
            </div>
          </div>
        ))}
      </div>
      <div className="px-3 pb-3">
        <button className="btn-accent flex items-center gap-1.5 h-8 px-3 rounded-lg text-[12px] font-bold w-full justify-center">
          <Scissors className="size-3.5" /> Exportar cortes
        </button>
      </div>
    </div>
  )
}

function DescriptionCard() {
  return (
    <div className="glass-card rounded-xl overflow-hidden max-w-lg">
      <div className="px-4 pt-3 pb-2" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
        <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-white/30">Descrição + Tags · SEO otimizado</p>
      </div>
      <div className="p-4 flex flex-col gap-3 text-[13px]">
        <p className="text-white/70 leading-relaxed">
          Nesse vídeo eu mostro os 3 erros que mais custam seguidores no YouTube — e como corrigi todos em menos de 30 dias. Se você está travado nos inscritos, esse vídeo é pra você.<br /><br />
          <span className="text-white/40">⏱ Timestamps · 📌 Links · 🔔 Notificações</span>
        </p>
        <div className="flex flex-wrap gap-1.5">
          {['youtube crescer', 'como crescer no youtube', 'canal do youtube', 'criador de conteudo', 'youtube 2026'].map((t) => (
            <span key={t} className="flex items-center gap-1 text-[10.5px] px-2.5 py-1 rounded" style={{ background: 'rgba(255,255,255,0.06)', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.10)' }}>
              <Tag className="size-2.5" />{t}
            </span>
          ))}
        </div>
      </div>
      <div className="flex items-center gap-2 px-4 pb-4">
        <button className="btn-accent flex items-center gap-1.5 h-8 px-3 rounded-lg text-[12px] font-bold flex-1 justify-center">
          <Copy className="size-3.5" /> Copiar tudo
        </button>
        <button className="flex items-center gap-1.5 h-8 px-3 rounded-lg text-[12px] text-white/50" style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid #1f1f24' }}>
          <RefreshCw className="size-3.5" /> Refazer
        </button>
      </div>
    </div>
  )
}
